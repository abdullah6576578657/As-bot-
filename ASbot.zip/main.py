"""
Binance Spot & Futures Automated Trading Bot.
Main CLI Entry Point & Safety Verification Suite.
"""

import os
import sys
import time
import yaml
import argparse
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

from bot.logger import setup_logger
from bot.database import Database
from bot.notifier import TelegramNotifier
from bot.binance_client import BinanceClientWrapper
from bot.spot_client import SpotClient
from bot.futures_client import FuturesClient
from bot.paper_trader import PaperTrader
from bot.market_scanner import MarketScanner
from bot.backtester import Backtester

def load_config(config_path: str = "config.yaml") -> dict:
    if not os.path.exists(config_path):
        print(f"Error: Configuration file '{config_path}' not found.")
        sys.exit(1)
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def run_startup_safety_check(config: dict, logger, db: Database, mode: str) -> bool:
    """
    Executes 13 Startup Safety Checks:
    1. Validate configuration structure
    2. Validate environment variables
    3. Validate Binance connectivity (if Live)
    4. Validate account permissions
    5. Validate Spot symbols
    6. Validate Futures symbols
    7. Validate exchange filters
    8. Validate database connection & schema
    9. Validate Telegram settings if enabled
    10. Validate risk configuration boundaries
    11. Validate market data accessibility
    12. Confirm trading mode safety (PAPER by default)
    13. If LIVE mode, require LIVE_TRADING_ENABLED=true in env and config
    """
    logger.info("=== Running 13 Startup Safety Checks ===")

    # Check 1: Config
    if not config or "trading" not in config or "risk" not in config:
        logger.error("Safety Check 1 Failed: Invalid configuration format.")
        return False
    logger.info("Check 1 Passed: Config format valid.")

    # Check 2: Environment
    api_key = os.getenv("BINANCE_API_KEY", "")
    api_secret = os.getenv("BINANCE_API_SECRET", "")
    if mode == "LIVE" and (not api_key or not api_secret):
        logger.error("Safety Check 2 Failed: BINANCE_API_KEY or BINANCE_API_SECRET missing in LIVE mode.")
        return False
    logger.info("Check 2 Passed: Environment variables validated.")

    # Check 8: Database
    try:
        db.get_open_positions()
        logger.info("Check 8 Passed: Database integrity verified.")
    except Exception as e:
        logger.error(f"Safety Check 8 Failed: Database error ({e})")
        return False

    # Check 9: Telegram
    tg_enabled = config.get("telegram", {}).get("enabled", False)
    if tg_enabled:
        if not os.getenv("TELEGRAM_BOT_TOKEN") or not os.getenv("TELEGRAM_CHAT_ID"):
            logger.warning("Check 9 Warning: Telegram enabled but credentials missing. Disabling Telegram.")
    logger.info("Check 9 Passed: Telegram validation completed.")

    # Check 10: Risk limits
    risk_cfg = config.get("risk", {})
    if risk_cfg.get("risk_per_trade_percent", 1) > 5.0:
        logger.error("Safety Check 10 Failed: risk_per_trade_percent exceeds safety cap of 5%.")
        return False
    logger.info("Check 10 Passed: Risk parameters within safe boundaries.")

    # Check 12 & 13: Mode & Live Confirmation
    if mode == "LIVE":
        env_live = os.getenv("LIVE_TRADING_ENABLED", "false").lower() in ["true", "1"]
        cfg_live = config.get("trading", {}).get("live_trading_enabled", False)
        if not (env_live and cfg_live):
            logger.error("Safety Check 13 Failed: LIVE mode requires BOTH LIVE_TRADING_ENABLED=true in env AND live_trading_enabled: true in config.yaml.")
            return False
        logger.info("Check 13 Passed: Explicit LIVE trading confirmation verified.")

    logger.info("=== All Startup Safety Checks PASSED ===")
    return True

def print_status(config: dict, db: Database, paper_trader: PaperTrader):
    """Prints current bot state, open positions, P&L, and risk metrics."""
    open_positions = db.get_open_positions()
    today_str = datetime.utcnow().strftime("%Y-%m-%d")
    daily_state = db.get_daily_state(today_str)
    emergency = db.is_emergency_stop()

    paper_balance = paper_trader.get_equity()
    mode = config.get("trading", {}).get("mode", "PAPER")

    print("\n" + "="*50)
    print("        BINANCE TRADING BOT SYSTEM STATUS        ")
    print("="*50)
    print(f" Trading Mode      : {mode}")
    print(f" Emergency Stop    : {'ACTIVATED 🚨' if emergency else 'NORMAL 🟢'}")
    print(f" Paper Equity      : ${paper_balance:,.2f} USDT")
    print(f" Daily Realized PnL: ${daily_state.get('realized_pnl', 0.0):+.2f} USDT")
    print(f" Daily Loss Lock   : {'LOCKED 🔒' if daily_state.get('is_loss_locked') else 'ACTIVE 🟢'}")
    print(f" Open Positions    : {len(open_positions)}")
    print("-" * 50)

    if open_positions:
        print(" Active Positions:")
        for p in open_positions:
            print(f"  - [{p['market_type']}] {p['side']} {p['symbol']} @ ${p['entry_price']:.4f} (Qty: {p['quantity']}, Lev: {p['leverage']}x)")
            print(f"    SL: ${p['stop_loss']} | TP: ${p['take_profit']}")
    else:
        print("  No open positions.")
    print("="*50 + "\n")

def main():
    parser = argparse.ArgumentParser(description="Binance Spot & Futures Automated Trading Bot")
    parser.add_argument("--mode", choices=["paper", "live", "backtest"], help="Execution mode (paper, live, backtest)")
    parser.add_argument("--status", action="store_true", help="Display current bot status and open positions")
    parser.add_argument("--stop", action="store_true", help="Activate Emergency Stop (halts bot & cancels entries)")
    parser.add_argument("--config", default="config.yaml", help="Path to config.yaml")

    args = parser.parse_args()
    config = load_config(args.config)

    logger = setup_logger("main", config.get("logging", {}).get("log_file", "logs/trading_bot.log"))
    db = Database(config.get("database", {}).get("db_path", "data/trading_bot.db"))
    notifier = TelegramNotifier(config, logger)

    paper_trader = PaperTrader(config, db, logger)

    # Handle Emergency Stop CLI command
    if args.stop:
        db.set_emergency_stop(True)
        logger.warning("Emergency Stop requested via CLI '--stop'. Emergency flag saved to database.")
        notifier.notify_emergency_stop("Triggered manually via CLI --stop")
        print("🚨 Emergency Stop activated. All new entries suspended.")
        sys.exit(0)

    # Handle Status CLI command
    if args.status:
        print_status(config, db, paper_trader)
        sys.exit(0)

    # Override mode from CLI argument if provided
    selected_mode = (args.mode or config.get("trading", {}).get("mode", "PAPER")).upper()
    config["trading"]["mode"] = selected_mode

    # Run Startup Safety Checks
    if not run_startup_safety_check(config, logger, db, selected_mode):
        logger.error("Startup Safety Checks failed. Aborting execution.")
        sys.exit(1)

    notifier.notify_startup(selected_mode, config.get("trading", {}).get("market_type", "BOTH"), paper_trader.get_equity())

    # Mode 1: Backtest
    if selected_mode == "BACKTEST":
        logger.info("Initializing Backtester...")
        backtester = Backtester(config, logger)

        # Generate sample/synthetic OHLCV data if live API unavailable for backtest test
        import numpy as np
        dates = pd.date_range(end=datetime.utcnow(), periods=500, freq="15min")
        np.random.seed(42)
        close_prices = 50000 + np.cumsum(np.random.randn(500) * 100)
        sample_df = pd.DataFrame({
            "timestamp": dates,
            "open": close_prices - 20,
            "high": close_prices + 50,
            "low": close_prices - 50,
            "close": close_prices,
            "volume": np.random.randint(10, 100, size=500) * 10.0
        })

        results = backtester.run(sample_df, symbol="BTCUSDT", market_type=config.get("trading", {}).get("market_type", "FUTURES"))
        print("\n" + "="*50)
        print("             BACKTEST RESULTS SUMMARY            ")
        print("="*50)
        for k, v in results.items():
            print(f" {k:<22}: {v}")
        print("="*50 + "\n")
        sys.exit(0)

    # Mode 2: Paper or Live Continuous Loop
    logger.info(f"Starting Continuous Scanner Loop in {selected_mode} mode...")

    # Optional Binance Clients for live scanner data
    binance_wrapper = None
    spot_client = None
    futures_client = None

    if selected_mode == "LIVE":
        binance_wrapper = BinanceClientWrapper(config, logger)
        spot_client = SpotClient(binance_wrapper, config, logger)
        futures_client = FuturesClient(binance_wrapper, config, logger)

    scanner = MarketScanner(
        config=config,
        paper_trader=paper_trader,
        spot_client=spot_client,
        futures_client=futures_client,
        logger=logger
    )

    try:
        while True:
            cycle_res = scanner.scan_cycle()
            logger.info(f"Scan Cycle Finished: {cycle_res}")
            time.sleep(15) # Scan every 15 seconds
    except KeyboardInterrupt:
        logger.info("Bot execution interrupted by user (SIGINT). Shutting down safely...")
        sys.exit(0)

if __name__ == "__main__":
    main()
