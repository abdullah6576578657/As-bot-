"""
Binance Spot Client.
Manages Spot symbol filters (LOT_SIZE, PRICE_FILTER, MIN_NOTIONAL),
validates order parameters, fetches balances, and executes Spot trades safely.
"""

import math
import logging
from typing import Dict, Any, Tuple, Optional
from bot.binance_client import BinanceClientWrapper

class SpotClient:
    """Handles Binance Spot trading operations and filter validation."""

    def __init__(self, wrapper: BinanceClientWrapper, config: Dict[str, Any], logger: Optional[logging.Logger] = None):
        self.wrapper = wrapper
        self.config = config or {}
        self.logger = logger or logging.getLogger(__name__)

    def get_symbol_filters(self, symbol: str) -> Dict[str, Any]:
        """Fetches and parses Binance Spot exchange information filters for symbol."""
        if not self.wrapper.client:
            return {}

        info = self.wrapper.execute_with_retry(self.wrapper.client.get_symbol_info, symbol=symbol)
        if not info or info.get("status") != "TRADING":
            self.logger.warning(f"Symbol {symbol} is not currently active for trading on Spot.")
            return {}

        filters = {}
        for f in info.get("filters", []):
            f_type = f.get("filterType")
            if f_type == "LOT_SIZE":
                filters["min_qty"] = float(f.get("minQty", 0.0))
                filters["max_qty"] = float(f.get("maxQty", 0.0))
                filters["step_size"] = float(f.get("stepSize", 0.0))
            elif f_type == "PRICE_FILTER":
                filters["min_price"] = float(f.get("minPrice", 0.0))
                filters["max_price"] = float(f.get("maxPrice", 0.0))
                filters["tick_size"] = float(f.get("tickSize", 0.0))
            elif f_type in ["MIN_NOTIONAL", "NOTIONAL"]:
                filters["min_notional"] = float(f.get("minNotional", f.get("notional", 10.0)))

        return filters

    def validate_and_format_order(self, symbol: str, price: float, quantity: float) -> Tuple[bool, float, float, str]:
        """
        Validates price and quantity against Spot trading filters and formats them to proper precision.
        Returns (is_valid, formatted_price, formatted_qty, reason).
        """
        filters = self.get_symbol_filters(symbol)
        if not filters:
            return False, 0.0, 0.0, f"Could not retrieve active Spot filters for {symbol}"

        step_size = filters.get("step_size", 0.0)
        tick_size = filters.get("tick_size", 0.0)
        min_qty = filters.get("min_qty", 0.0)
        max_qty = filters.get("max_qty", float('inf'))
        min_notional = filters.get("min_notional", 10.0)

        # Format quantity to step size step
        if step_size > 0:
            qty_precision = int(round(-math.log10(step_size)))
            formatted_qty = round(math.floor(quantity / step_size) * step_size, qty_precision)
        else:
            formatted_qty = quantity

        # Format price to tick size step
        if tick_size > 0:
            price_precision = int(round(-math.log10(tick_size)))
            formatted_price = round(math.floor(price / tick_size) * tick_size, price_precision)
        else:
            formatted_price = price

        if formatted_qty < min_qty:
            return False, 0.0, 0.0, f"Quantity {formatted_qty} below minimum allowed quantity {min_qty}"

        if formatted_qty > max_qty:
            return False, 0.0, 0.0, f"Quantity {formatted_qty} exceeds maximum allowed quantity {max_qty}"

        notional = formatted_price * formatted_qty
        if notional < min_notional:
            return False, 0.0, 0.0, f"Order notional (${notional:.2f}) below minimum required (${min_notional:.2f})"

        return True, formatted_price, formatted_qty, "Valid"

    def get_account_balance(self, asset: str = "USDT") -> float:
        """Retrieves free asset balance from Binance Spot account."""
        if not self.wrapper.client:
            return 0.0

        res = self.wrapper.execute_with_retry(self.wrapper.client.get_asset_balance, asset=asset)
        if res:
            return float(res.get("free", 0.0))
        return 0.0

    def place_order(self, symbol: str, side: str, quantity: float, price: Optional[float] = None, order_type: str = "MARKET") -> Dict[str, Any]:
        """Places a Spot order on Binance after filter validation."""
        if not self.wrapper.client:
            raise RuntimeError("Binance client not initialized for live orders.")

        is_valid, fmt_price, fmt_qty, reason = self.validate_and_format_order(symbol, price or 1.0, quantity)
        if not is_valid:
            self.logger.error(f"Spot order validation failed: {reason}")
            raise ValueError(f"Spot order invalid: {reason}")

        params = {
            "symbol": symbol,
            "side": side.upper(),
            "type": order_type.upper(),
            "quantity": fmt_qty
        }

        if order_type.upper() == "LIMIT":
            params["price"] = str(fmt_price)
            params["timeInForce"] = "GTC"

        res = self.wrapper.execute_with_retry(self.wrapper.client.create_order, **params)
        return res
