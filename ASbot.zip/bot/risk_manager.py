"""
Risk Management Engine.
Handles:
- Risk-based position sizing (Account Equity x Risk %)
- Dynamic Futures leverage calculation based on volatility (ATR), trend strength (ADX), regime, and liquidation risk
- Dynamic Stop-Loss calculation (ATR, swing highs/lows, support/resistance)
- Dynamic Take-Profit calculation (Risk:Reward ratios, support/resistance targets)
- Futures liquidation risk estimation & margin checks
- Daily loss tracking and Daily Loss Lock state persistence
- Maximum total exposure, concurrent trades, and correlation limits
"""

import math
from datetime import datetime
from typing import Dict, Any, List, Tuple, Optional
import pandas as pd
from bot.database import Database

class RiskManager:
    """Central Risk and Position Management Engine."""

    def __init__(self, config: Dict[str, Any], db: Optional[Database] = None):
        self.config = config or {}
        self.db = db or Database(self.config.get("database", {}).get("db_path", "data/trading_bot.db"))
        
        self.risk_cfg = self.config.get("risk", {})
        self.futures_cfg = self.config.get("futures", {})
        
        self.risk_per_trade_pct = self.risk_cfg.get("risk_per_trade_percent", 1.0)
        self.max_daily_loss_pct = self.risk_cfg.get("max_daily_loss_percent", 3.0)
        self.max_spot_trades = self.risk_cfg.get("max_concurrent_spot_trades", 3)
        self.max_futures_trades = self.risk_cfg.get("max_concurrent_futures_trades", 3)
        self.max_total_exposure_pct = self.risk_cfg.get("max_total_exposure_percent", 30.0)

    def is_daily_loss_locked(self, account_equity: float) -> Tuple[bool, float]:
        """
        Checks if the daily loss limit has been breached.
        Returns (is_locked, current_daily_loss_usdt).
        """
        today_str = datetime.utcnow().strftime("%Y-%m-%d")
        daily_state = self.db.get_daily_state(today_str)

        if daily_state.get("is_loss_locked", 0) == 1:
            return True, daily_state.get("realized_pnl", 0.0)

        realized_pnl = daily_state.get("realized_pnl", 0.0)
        max_allowed_loss_usdt = (self.max_daily_loss_pct / 100.0) * account_equity

        if realized_pnl <= -max_allowed_loss_usdt and max_allowed_loss_usdt > 0:
            self.db.update_daily_state(today_str, is_loss_locked=True)
            return True, realized_pnl

        return False, realized_pnl

    def calculate_dynamic_leverage(self, df: pd.DataFrame, regime_info: Dict[str, Any]) -> int:
        """
        Dynamically calculates Futures leverage based on ATR volatility, ADX trend strength, and regime.
        Higher volatility -> Lower leverage.
        Strong trend + controlled volatility -> Higher leverage up to max_leverage.
        Never exceeds max_leverage.
        """
        if not self.futures_cfg.get("dynamic_leverage", True):
            return self.futures_cfg.get("min_leverage", 1)

        min_lev = int(self.futures_cfg.get("min_leverage", 1))
        max_lev = int(self.futures_cfg.get("max_leverage", 5))

        if df is None or len(df) < 20:
            return min_lev

        row = df.iloc[-2] if len(df) > 1 else df.iloc[-1]
        close = row["close"]
        atr = row.get("atr", close * 0.02)
        adx = row.get("adx", 20.0)

        # Volatility ratio (ATR / Price)
        volatility_pct = (atr / close) * 100.0

        if volatility_pct > 4.0:
            # Extreme volatility: enforce lowest leverage
            return min_lev
        elif volatility_pct > 2.5:
            # High volatility
            leverage = min_lev
        elif volatility_pct < 1.0 and adx > 25:
            # Low volatility + Strong trend
            leverage = max_lev
        else:
            # Moderate volatility
            leverage = math.floor((min_lev + max_lev) / 2)

        return max(min_lev, min(max_lev, leverage))

    def calculate_dynamic_stop_loss(self, df: pd.DataFrame, side: str, entry_price: float) -> float:
        """
        Calculates Stop-Loss price using ATR and recent swing High/Low,
        ensuring SL % stays within min/max limits.
        Must be called BEFORE position size calculation.
        """
        min_sl_pct = self.futures_cfg.get("min_stop_loss_percent", 0.5) / 100.0
        max_sl_pct = self.futures_cfg.get("max_stop_loss_percent", 3.0) / 100.0

        if df is not None and len(df) >= 20:
            row = df.iloc[-2] if len(df) > 1 else df.iloc[-1]
            atr = row.get("atr", entry_price * 0.015)
            
            # Use 2 x ATR as baseline SL distance
            atr_sl_dist = atr * 2.0
            
            if side in ["BUY", "LONG"]:
                swing_low = df["low"].iloc[-10:-1].min()
                candidate_sl = min(entry_price - atr_sl_dist, swing_low * 0.998)
                sl_pct = (entry_price - candidate_sl) / entry_price
            else: # SHORT
                swing_high = df["high"].iloc[-10:-1].max()
                candidate_sl = max(entry_price + atr_sl_dist, swing_high * 1.002)
                sl_pct = (candidate_sl - entry_price) / entry_price
        else:
            sl_pct = 0.015
            candidate_sl = entry_price * (1 - sl_pct) if side in ["BUY", "LONG"] else entry_price * (1 + sl_pct)

        # Enforce safety boundaries
        sl_pct_clamped = max(min_sl_pct, min(max_sl_pct, sl_pct))

        if side in ["BUY", "LONG"]:
            final_sl = entry_price * (1.0 - sl_pct_clamped)
        else:
            final_sl = entry_price * (1.0 + sl_pct_clamped)

        return round(final_sl, 6)

    def calculate_dynamic_take_profit(self, entry_price: float, stop_loss: float, side: str, df: Optional[pd.DataFrame] = None) -> float:
        """
        Calculates Take-Profit price based on Risk/Reward target ratio.
        """
        target_rr = self.futures_cfg.get("target_risk_reward", 2.0)
        sl_distance = abs(entry_price - stop_loss)

        if side in ["BUY", "LONG"]:
            tp_price = entry_price + (sl_distance * target_rr)
        else:
            tp_price = entry_price - (sl_distance * target_rr)

        return round(tp_price, 6)

    def calculate_position_size(
        self,
        account_equity: float,
        entry_price: float,
        stop_loss: float,
        leverage: int = 1,
        fee_rate: float = 0.0004
    ) -> float:
        """
        Calculates quantity based on account equity and risk percentage.
        Risk Amount = Account Equity x Risk %
        Quantity = Risk Amount / (SL Distance + Fee Buffer)
        Leverage does NOT increase total account risk amount.
        """
        if entry_price <= 0 or stop_loss <= 0 or account_equity <= 0:
            return 0.0

        max_risk_amount = account_equity * (self.risk_per_trade_pct / 100.0)
        sl_distance = abs(entry_price - stop_loss)

        if sl_distance <= 0:
            return 0.0

        # Estimated fee per unit traded (entry + exit)
        estimated_fee_per_unit = entry_price * fee_rate * 2.0
        risk_per_unit = sl_distance + estimated_fee_per_unit

        raw_quantity = max_risk_amount / risk_per_unit

        # Verify margin requirement for Futures
        required_margin = (raw_quantity * entry_price) / leverage
        max_allowed_margin = account_equity * 0.25 # Don't allocate more than 25% equity into single trade margin

        if required_margin > max_allowed_margin:
            raw_quantity = (max_allowed_margin * leverage) / entry_price

        return raw_quantity

    def check_liquidation_risk(self, entry_price: float, stop_loss: float, side: str, leverage: int, margin_mode: str = "ISOLATED") -> bool:
        """
        Calculates estimated Futures liquidation price and ensures stop loss triggers well before liquidation.
        Returns True if safe, False if unsafe.
        """
        if leverage <= 1:
            return True

        # Maintenance margin rate approximation (0.5% for standard contracts)
        mmr = 0.005
        safety_margin_pct = self.futures_cfg.get("liquidation_safety_margin_percent", 2.0) / 100.0

        if side == "LONG":
            # Est Liquidation Price (ISOLATED LONG) ~ Entry * (1 - (1/leverage) + mmr)
            est_liq_price = entry_price * (1.0 - (1.0 / leverage) + mmr)
            # SL must be above liquidation price with safety margin
            min_safe_sl = est_liq_price * (1.0 + safety_margin_pct)
            if stop_loss <= min_safe_sl:
                return False
        elif side == "SHORT":
            # Est Liquidation Price (ISOLATED SHORT) ~ Entry * (1 + (1/leverage) - mmr)
            est_liq_price = entry_price * (1.0 + (1.0 / leverage) - mmr)
            max_safe_sl = est_liq_price * (1.0 - safety_margin_pct)
            if stop_loss >= max_safe_sl:
                return False

        return True

    def validate_new_trade_capacity(self, market_type: str, new_position_value: float, account_equity: float) -> Tuple[bool, str]:
        """
        Validates maximum concurrent positions and total account exposure limits.
        """
        open_positions = self.db.get_open_positions()

        spot_count = sum(1 for p in open_positions if p["market_type"] == "SPOT")
        futures_count = sum(1 for p in open_positions if p["market_type"] == "FUTURES")

        if market_type == "SPOT" and spot_count >= self.max_spot_trades:
            return False, f"Max concurrent Spot trades ({self.max_spot_trades}) reached"

        if market_type == "FUTURES" and futures_count >= self.max_futures_trades:
            return False, f"Max concurrent Futures trades ({self.max_futures_trades}) reached"

        current_exposure = sum(p["entry_price"] * p["quantity"] for p in open_positions)
        total_exposure = current_exposure + new_position_value
        max_exposure_usdt = account_equity * (self.max_total_exposure_pct / 100.0)

        if total_exposure > max_exposure_usdt:
            return False, f"Total exposure limit (${max_exposure_usdt:.2f}) exceeded"

        return True, "Capacity check passed"
