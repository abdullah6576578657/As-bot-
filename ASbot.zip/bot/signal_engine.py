"""
Weighted Signal Engine.
Evaluates 12 technical indicators on market data to generate BUY, SELL, or NEUTRAL scores,
calculates confidence percentage and agreeing indicator counts, and determines trade signals.
"""

from typing import Dict, Any, Tuple
import pandas as pd

class SignalEngine:
    """Evaluates indicators with configured weights to generate trade signals."""

    DEFAULT_WEIGHTS = {
        "ema_cross": 10,
        "rsi": 8,
        "macd": 10,
        "bollinger": 8,
        "volume": 10,
        "stochastic": 6,
        "adx": 8,
        "fibonacci": 8,
        "vwap": 8,
        "ichimoku": 10,
        "obv": 8
    }

    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        signals_cfg = self.config.get("signals", {})
        self.confidence_threshold = signals_cfg.get("confidence_threshold", 70.0)
        self.min_agreement = signals_cfg.get("minimum_indicator_agreement", 6)
        self.weights = signals_cfg.get("weights", self.DEFAULT_WEIGHTS)

    def evaluate(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Evaluates the last closed candle (ignoring unclosed candle if needed) and returns signal metrics.
        """
        if df is None or len(df) < 30:
            return {
                "signal": "NEUTRAL",
                "confidence": 0.0,
                "buy_score": 0.0,
                "sell_score": 0.0,
                "agreeing_indicators": 0,
                "reasons": ["Insufficient data for signal evaluation"]
            }

        row = df.iloc[-2] if len(df) > 1 else df.iloc[-1]
        prev_row = df.iloc[-3] if len(df) > 2 else df.iloc[-2]

        buy_score = 0.0
        sell_score = 0.0
        max_score = sum(self.weights.values())

        buy_agree = 0
        sell_agree = 0
        reasons = []

        # 1. EMA Crossover (EMA 9 vs EMA 21)
        w_ema = self.weights.get("ema_cross", 10)
        if row["ema_9"] > row["ema_21"]:
            buy_score += w_ema
            buy_agree += 1
            if prev_row["ema_9"] <= prev_row["ema_21"]:
                reasons.append("EMA 9 crossed above EMA 21 (Bullish)")
            else:
                reasons.append("EMA 9 above EMA 21")
        elif row["ema_9"] < row["ema_21"]:
            sell_score += w_ema
            sell_agree += 1
            if prev_row["ema_9"] >= prev_row["ema_21"]:
                reasons.append("EMA 9 crossed below EMA 21 (Bearish)")
            else:
                reasons.append("EMA 9 below EMA 21")

        # 2. RSI
        w_rsi = self.weights.get("rsi", 8)
        if row["rsi"] < 35:
            buy_score += w_rsi
            buy_agree += 1
            reasons.append(f"RSI oversold ({row['rsi']:.1f})")
        elif row["rsi"] > 65:
            sell_score += w_rsi
            sell_agree += 1
            reasons.append(f"RSI overbought ({row['rsi']:.1f})")
        elif 50 <= row["rsi"] < 65:
            buy_score += w_rsi * 0.5
        elif 35 < row["rsi"] < 50:
            sell_score += w_rsi * 0.5

        # 3. MACD
        w_macd = self.weights.get("macd", 10)
        if row["macd_hist"] > 0:
            buy_score += w_macd
            buy_agree += 1
            reasons.append("MACD histogram positive")
        elif row["macd_hist"] < 0:
            sell_score += w_macd
            sell_agree += 1
            reasons.append("MACD histogram negative")

        # 4. Bollinger Bands
        w_bb = self.weights.get("bollinger", 8)
        if row["close"] <= row["bb_lower"]:
            buy_score += w_bb
            buy_agree += 1
            reasons.append("Price near/below lower Bollinger Band")
        elif row["close"] >= row["bb_upper"]:
            sell_score += w_bb
            sell_agree += 1
            reasons.append("Price near/above upper Bollinger Band")

        # 5. Volume Analysis
        w_vol = self.weights.get("volume", 10)
        if row["volume_ratio"] > 1.2 and row["close"] > row["open"]:
            buy_score += w_vol
            buy_agree += 1
            reasons.append("High volume bullish candle")
        elif row["volume_ratio"] > 1.2 and row["close"] < row["open"]:
            sell_score += w_vol
            sell_agree += 1
            reasons.append("High volume bearish candle")

        # 6. Stochastic Oscillator
        w_stoch = self.weights.get("stochastic", 6)
        if row["stoch_k"] < 20 and row["stoch_k"] > row["stoch_d"]:
            buy_score += w_stoch
            buy_agree += 1
            reasons.append("Stochastic bullish cross in oversold zone")
        elif row["stoch_k"] > 80 and row["stoch_k"] < row["stoch_d"]:
            sell_score += w_stoch
            sell_agree += 1
            reasons.append("Stochastic bearish cross in overbought zone")

        # 7. ADX Trend Strength
        w_adx = self.weights.get("adx", 8)
        if row["adx"] > 25:
            if row["plus_di"] > row["minus_di"]:
                buy_score += w_adx
                buy_agree += 1
                reasons.append(f"Strong uptrend ADX ({row['adx']:.1f})")
            elif row["minus_di"] > row["plus_di"]:
                sell_score += w_adx
                sell_agree += 1
                reasons.append(f"Strong downtrend ADX ({row['adx']:.1f})")

        # 8. Fibonacci Retracement
        w_fib = self.weights.get("fibonacci", 8)
        if abs(row["close"] - row["fib_618"]) / row["close"] < 0.01 and row["close"] > prev_row["close"]:
            buy_score += w_fib
            buy_agree += 1
            reasons.append("Price bouncing off 61.8% Fib retracement")
        elif abs(row["close"] - row["fib_382"]) / row["close"] < 0.01 and row["close"] < prev_row["close"]:
            sell_score += w_fib
            sell_agree += 1
            reasons.append("Price rejected at 38.2% Fib retracement")

        # 9. VWAP
        w_vwap = self.weights.get("vwap", 8)
        if row["close"] > row["vwap"]:
            buy_score += w_vwap
            buy_agree += 1
            reasons.append("Price above VWAP")
        elif row["close"] < row["vwap"]:
            sell_score += w_vwap
            sell_agree += 1
            reasons.append("Price below VWAP")

        # 10. Ichimoku Cloud
        w_ichi = self.weights.get("ichimoku", 10)
        cloud_top = max(row["ichimoku_span_a"], row["ichimoku_span_b"])
        cloud_bottom = min(row["ichimoku_span_a"], row["ichimoku_span_b"])

        if row["close"] > cloud_top and row["ichimoku_tenkan"] > row["ichimoku_kijun"]:
            buy_score += w_ichi
            buy_agree += 1
            reasons.append("Ichimoku bullish cloud breakout")
        elif row["close"] < cloud_bottom and row["ichimoku_tenkan"] < row["ichimoku_kijun"]:
            sell_score += w_ichi
            sell_agree += 1
            reasons.append("Ichimoku bearish cloud breakout")

        # 11. OBV
        w_obv = self.weights.get("obv", 8)
        if row["obv"] > row["obv_ema"]:
            buy_score += w_obv
            buy_agree += 1
            reasons.append("OBV above moving average")
        elif row["obv"] < row["obv_ema"]:
            sell_score += w_obv
            sell_agree += 1
            reasons.append("OBV below moving average")

        # Calculate Final Confidence & Signal
        buy_confidence = (buy_score / max_score) * 100.0
        sell_confidence = (sell_score / max_score) * 100.0

        if buy_confidence >= self.confidence_threshold and buy_agree >= self.min_agreement and buy_confidence > sell_confidence:
            signal = "BUY"
            final_confidence = buy_confidence
            agreeing = buy_agree
        elif sell_confidence >= self.confidence_threshold and sell_agree >= self.min_agreement and sell_confidence > buy_confidence:
            signal = "SELL"
            final_confidence = sell_confidence
            agreeing = sell_agree
        else:
            signal = "NEUTRAL"
            final_confidence = max(buy_confidence, sell_confidence)
            agreeing = max(buy_agree, sell_agree)

        return {
            "signal": signal,
            "confidence": round(final_confidence, 2),
            "buy_score": round(buy_confidence, 2),
            "sell_score": round(sell_confidence, 2),
            "agreeing_indicators": agreeing,
            "reasons": reasons
        }
