"""
Vectorized Technical Indicator Calculation Module.
Calculates 12 technical indicators on OHLCV pandas DataFrames:
1. EMA (9 & 21)
2. RSI
3. MACD
4. Bollinger Bands
5. Volume Analysis (Volume SMA & Spike)
6. Stochastic Oscillator
7. ADX
8. Fibonacci Retracements
9. VWAP
10. Ichimoku Cloud
11. OBV
12. ATR (used for SL/TP and Volatility)

Handles insufficient data cleanly and ignores incomplete candles.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any

class TechnicalIndicators:
    """Provides pure numpy/pandas implementations of standard technical indicators."""

    @staticmethod
    def calculate_all(df: pd.DataFrame, config: Dict[str, Any] = None) -> pd.DataFrame:
        """Runs all indicator calculations and attaches columns to the DataFrame."""
        if df is None or len(df) < 30:
            return df

        df = df.copy()
        
        # Ensure correct numerical dtypes
        for col in ["open", "high", "low", "close", "volume"]:
            df[col] = df[col].astype(float)

        df = TechnicalIndicators.ema(df, period=9, col_name="ema_9")
        df = TechnicalIndicators.ema(df, period=21, col_name="ema_21")
        df = TechnicalIndicators.rsi(df, period=14)
        df = TechnicalIndicators.macd(df, fast=12, slow=26, signal=9)
        df = TechnicalIndicators.bollinger_bands(df, period=20, std_dev=2.0)
        df = TechnicalIndicators.volume_analysis(df, period=20)
        df = TechnicalIndicators.stochastic(df, k_period=14, d_period=3)
        df = TechnicalIndicators.adx(df, period=14)
        df = TechnicalIndicators.fibonacci(df, period=50)
        df = TechnicalIndicators.vwap(df)
        df = TechnicalIndicators.ichimoku(df)
        df = TechnicalIndicators.obv(df)
        df = TechnicalIndicators.atr(df, period=14)

        return df

    @staticmethod
    def ema(df: pd.DataFrame, period: int = 14, col_name: str = "ema") -> pd.DataFrame:
        df[col_name] = df["close"].ewm(span=period, adjust=False).mean()
        return df

    @staticmethod
    def rsi(df: pd.DataFrame, period: int = 14) -> pd.DataFrame:
        delta = df["close"].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()

        rs = gain / (loss.replace(0, np.nan))
        df["rsi"] = 100 - (100 / (1 + rs))
        df["rsi"] = df["rsi"].fillna(50.0)
        return df

    @staticmethod
    def macd(df: pd.DataFrame, fast: int = 12, slow: int = 26, signal: int = 9) -> pd.DataFrame:
        fast_ema = df["close"].ewm(span=fast, adjust=False).mean()
        slow_ema = df["close"].ewm(span=slow, adjust=False).mean()
        df["macd_line"] = fast_ema - slow_ema
        df["macd_signal"] = df["macd_line"].ewm(span=signal, adjust=False).mean()
        df["macd_hist"] = df["macd_line"] - df["macd_signal"]
        return df

    @staticmethod
    def bollinger_bands(df: pd.DataFrame, period: int = 20, std_dev: float = 2.0) -> pd.DataFrame:
        sma = df["close"].rolling(window=period).mean()
        std = df["close"].rolling(window=period).std()
        df["bb_middle"] = sma
        df["bb_upper"] = sma + (std * std_dev)
        df["bb_lower"] = sma - (std * std_dev)
        return df

    @staticmethod
    def volume_analysis(df: pd.DataFrame, period: int = 20) -> pd.DataFrame:
        df["volume_sma"] = df["volume"].rolling(window=period).mean()
        df["volume_ratio"] = df["volume"] / df["volume_sma"].replace(0, np.nan)
        df["volume_ratio"] = df["volume_ratio"].fillna(1.0)
        return df

    @staticmethod
    def stochastic(df: pd.DataFrame, k_period: int = 14, d_period: int = 3) -> pd.DataFrame:
        low_min = df["low"].rolling(window=k_period).min()
        high_max = df["high"].rolling(window=k_period).max()
        stoch_k = 100 * ((df["close"] - low_min) / (high_max - low_min).replace(0, np.nan))
        df["stoch_k"] = stoch_k.fillna(50.0)
        df["stoch_d"] = df["stoch_k"].rolling(window=d_period).mean().fillna(50.0)
        return df

    @staticmethod
    def atr(df: pd.DataFrame, period: int = 14) -> pd.DataFrame:
        high_low = df["high"] - df["low"]
        high_close = (df["high"] - df["close"].shift()).abs()
        low_close = (df["low"] - df["close"].shift()).abs()
        tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        df["atr"] = tr.rolling(window=period).mean().bfill()
        return df

    @staticmethod
    def adx(df: pd.DataFrame, period: int = 14) -> pd.DataFrame:
        df = TechnicalIndicators.atr(df, period)
        up_move = df["high"] - df["high"].shift(1)
        down_move = df["low"].shift(1) - df["low"]

        pos_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
        neg_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)

        pos_di = 100 * (pd.Series(pos_dm).rolling(window=period).mean() / df["atr"].replace(0, np.nan))
        neg_di = 100 * (pd.Series(neg_dm).rolling(window=period).mean() / df["atr"].replace(0, np.nan))

        dx = 100 * (abs(pos_di - neg_di) / (pos_di + neg_di).replace(0, np.nan))
        df["adx"] = dx.rolling(window=period).mean().fillna(20.0)
        df["plus_di"] = pos_di.fillna(0.0)
        df["minus_di"] = neg_di.fillna(0.0)
        return df

    @staticmethod
    def fibonacci(df: pd.DataFrame, period: int = 50) -> pd.DataFrame:
        recent_high = df["high"].rolling(window=period).max()
        recent_low = df["low"].rolling(window=period).min()
        diff = recent_high - recent_low

        df["fib_236"] = recent_high - (diff * 0.236)
        df["fib_382"] = recent_high - (diff * 0.382)
        df["fib_500"] = recent_high - (diff * 0.500)
        df["fib_618"] = recent_high - (diff * 0.618)
        return df

    @staticmethod
    def vwap(df: pd.DataFrame) -> pd.DataFrame:
        typical_price = (df["high"] + df["low"] + df["close"]) / 3.0
        tp_v = typical_price * df["volume"]
        df["vwap"] = tp_v.cumsum() / df["volume"].cumsum().replace(0, np.nan)
        df["vwap"] = df["vwap"].fillna(df["close"])
        return df

    @staticmethod
    def ichimoku(df: pd.DataFrame) -> pd.DataFrame:
        # Conversion Line (Tenkan-sen): (9-period high + 9-period low)/2
        tenkan_high = df["high"].rolling(window=9).max()
        tenkan_low = df["low"].rolling(window=9).min()
        df["ichimoku_tenkan"] = (tenkan_high + tenkan_low) / 2.0

        # Base Line (Kijun-sen): (26-period high + 26-period low)/2
        kijun_high = df["high"].rolling(window=26).max()
        kijun_low = df["low"].rolling(window=26).min()
        df["ichimoku_kijun"] = (kijun_high + kijun_low) / 2.0

        # Leading Span A (Senkou Span A): (Tenkan-sen + Kijun-sen)/2
        df["ichimoku_span_a"] = ((df["ichimoku_tenkan"] + df["ichimoku_kijun"]) / 2.0)

        # Leading Span B (Senkou Span B): (52-period high + 52-period low)/2
        span_b_high = df["high"].rolling(window=52).max()
        span_b_low = df["low"].rolling(window=52).min()
        df["ichimoku_span_b"] = ((span_b_high + span_b_low) / 2.0)

        return df

    @staticmethod
    def obv(df: pd.DataFrame) -> pd.DataFrame:
        obv_val = (np.sign(df["close"].diff()) * df["volume"]).fillna(0).cumsum()
        df["obv"] = obv_val
        df["obv_ema"] = df["obv"].ewm(span=20, adjust=False).mean()
        return df
