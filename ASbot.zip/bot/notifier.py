"""
Telegram notifier module for sending real-time alerts.
Ensures no API keys or secrets are leaked.
"""

import os
import logging
import requests
from typing import Dict, Any, Optional

class TelegramNotifier:
    """Handles Telegram notification alerts for bot state changes and trades."""

    def __init__(self, config: Dict[str, Any], logger: Optional[logging.Logger] = None):
        self.config = config.get("telegram", {})
        self.enabled = self.config.get("enabled", False)
        self.logger = logger or logging.getLogger(__name__)

        self.bot_token = os.getenv("TELEGRAM_BOT_TOKEN")
        self.chat_id = os.getenv("TELEGRAM_CHAT_ID")

        if self.enabled and not (self.bot_token and self.chat_id):
            self.logger.warning("Telegram is enabled in config, but TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID is missing.")
            self.enabled = False

    def send_message(self, message: str) -> bool:
        """Sends a plain text / HTML formatted message to the configured Telegram chat."""
        if not self.enabled:
            return False

        url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        payload = {
            "chat_id": self.chat_id,
            "text": message,
            "parse_mode": "HTML"
        }

        try:
            response = requests.post(url, json=payload, timeout=5)
            if response.status_code == 200:
                return True
            else:
                self.logger.error(f"Failed to send Telegram notification. Response: {response.text}")
                return False
        except Exception as e:
            self.logger.error(f"Error sending Telegram message: {e}")
            return False

    def notify_startup(self, mode: str, market_type: str, equity: float):
        if not self.config.get("notify_on_startup", True):
            return
        msg = (
            f"🚀 <b>Trading Bot Started</b>\n"
            f"Mode: <b>{mode}</b>\n"
            f"Market Type: <b>{market_type}</b>\n"
            f"Initial Equity: <b>${equity:,.2f} USDT</b>"
        )
        self.send_message(msg)

    def notify_trade_entry(self, pos: Dict[str, Any]):
        if not self.config.get("notify_on_trade", True):
            return
        msg = (
            f"🟢 <b>TRADE OPENED [{pos['market_type']}]</b>\n"
            f"Symbol: <b>{pos['symbol']}</b>\n"
            f"Side: <b>{pos['side']}</b>\n"
            f"Price: <b>${pos['entry_price']:.4f}</b>\n"
            f"Qty: <b>{pos['quantity']}</b>\n"
            f"Leverage: <b>{pos.get('leverage', 1)}x</b>\n"
            f"SL: <b>${pos.get('stop_loss', 0):.4f}</b> | TP: <b>${pos.get('take_profit', 0):.4f}</b>\n"
            f"Reason: <i>{pos.get('entry_reason', 'N/A')}</i>"
        )
        self.send_message(msg)

    def notify_trade_exit(self, pos: Dict[str, Any]):
        if not self.config.get("notify_on_exit", True):
            return
        pnl = pos.get("realized_pnl", 0.0)
        icon = "🟩" if pnl >= 0 else "🟥"
        msg = (
            f"{icon} <b>TRADE CLOSED [{pos['market_type']}]</b>\n"
            f"Symbol: <b>{pos['symbol']}</b>\n"
            f"Side: <b>{pos['side']}</b>\n"
            f"Entry: <b>${pos['entry_price']:.4f}</b> | Exit: <b>${pos.get('exit_price', 0):.4f}</b>\n"
            f"Realized P&L: <b>${pnl:+.2f} USDT</b>\n"
            f"Exit Reason: <i>{pos.get('exit_reason', 'N/A')}</i>"
        )
        self.send_message(msg)

    def notify_daily_loss_lock(self, current_loss: float, limit: float):
        if not self.config.get("notify_on_daily_loss", True):
            return
        msg = (
            f"⚠️ <b>DAILY LOSS LIMIT REACHED</b>\n"
            f"Current Daily Loss: <b>-${abs(current_loss):.2f} USDT</b>\n"
            f"Configured Limit: <b>-${abs(limit):.2f} USDT</b>\n"
            f"Trading locked until next daily reset period."
        )
        self.send_message(msg)

    def notify_emergency_stop(self, reason: str):
        msg = (
            f"🚨 <b>EMERGENCY STOP ACTIVATED</b>\n"
            f"Reason: <i>{reason}</i>\n"
            f"Trading halted immediately. Pending orders cancelled."
        )
        self.send_message(msg)
