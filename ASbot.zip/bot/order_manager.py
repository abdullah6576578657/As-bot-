"""
Order Manager.
Tracks Binance order execution, stores order IDs, verifies fill quantity and fill price,
calculates fees, and reconciles state with Binance and SQLite database.
"""

import uuid
import logging
from typing import Dict, Any, Optional
from bot.database import Database

class OrderManager:
    """Manages order creation records, status updates, and reconciliation."""

    def __init__(self, db: Optional[Database] = None, logger: Optional[logging.Logger] = None):
        self.db = db or Database()
        self.logger = logger or logging.getLogger(__name__)

    def create_order_record(
        self,
        symbol: str,
        market_type: str,
        side: str,
        order_type: str,
        quantity: float,
        price: Optional[float] = None,
        position_id: Optional[str] = None,
        is_paper: bool = True
    ) -> Dict[str, Any]:
        """Creates a local order tracking object."""
        order_id = f"ord_{uuid.uuid4().hex[:12]}"
        order_data = {
            "order_id": order_id,
            "binance_order_id": None,
            "position_id": position_id,
            "symbol": symbol,
            "market_type": market_type,
            "side": side,
            "order_type": order_type,
            "price": price,
            "quantity": quantity,
            "status": "NEW",
            "executed_qty": 0.0,
            "avg_fill_price": price or 0.0,
            "fee": 0.0,
            "is_paper": is_paper
        }
        
        with self.db._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO orders (order_id, binance_order_id, position_id, symbol, market_type, side, order_type, price, quantity, status, executed_qty, avg_fill_price, fee, is_paper)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                order_data["order_id"], order_data["binance_order_id"], order_data["position_id"],
                order_data["symbol"], order_data["market_type"], order_data["side"], order_data["order_type"],
                order_data["price"], order_data["quantity"], order_data["status"], order_data["executed_qty"],
                order_data["avg_fill_price"], order_data["fee"], 1 if is_paper else 0
            ))
            conn.commit()

        return order_data

    def reconcile_fill(self, order_id: str, binance_res: Dict[str, Any], fee_rate: float = 0.0004) -> Dict[str, Any]:
        """Reconciles executed order with actual fill response from Binance."""
        binance_id = str(binance_res.get("orderId", ""))
        status = binance_res.get("status", "FILLED")
        executed_qty = float(binance_res.get("executedQty", binance_res.get("origQty", 0.0)))
        cum_quote = float(binance_res.get("cummulativeQuoteQty", 0.0))

        if executed_qty > 0 and cum_quote > 0:
            avg_price = cum_quote / executed_qty
        else:
            avg_price = float(binance_res.get("price", 0.0))

        fee = avg_price * executed_qty * fee_rate

        with self.db._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            UPDATE orders SET
                binance_order_id = ?,
                status = ?,
                executed_qty = ?,
                avg_fill_price = ?,
                fee = ?
            WHERE order_id = ?
            """, (binance_id, status, executed_qty, avg_price, fee, order_id))
            conn.commit()

        return {
            "order_id": order_id,
            "binance_order_id": binance_id,
            "status": status,
            "executed_qty": executed_qty,
            "avg_fill_price": avg_price,
            "fee": fee
        }
