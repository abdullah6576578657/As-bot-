"""
SQLite database persistence layer for state recovery, positions, orders, P&L, daily loss lock, and emergency flags.
"""

import os
import sqlite3
import json
from datetime import datetime
from typing import Dict, List, Any, Optional

class Database:
    """Handles SQLite persistence for bot operations."""
    
    def __init__(self, db_path: str = "data/trading_bot.db"):
        self.db_path = db_path
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Active and Closed Positions Table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS positions (
                position_id TEXT PRIMARY KEY,
                symbol TEXT NOT NULL,
                market_type TEXT NOT NULL, -- SPOT or FUTURES
                side TEXT NOT NULL,        -- BUY, LONG, SHORT
                status TEXT NOT NULL,      -- OPEN, CLOSED
                entry_price REAL NOT NULL,
                exit_price REAL,
                quantity REAL NOT NULL,
                leverage INTEGER DEFAULT 1,
                margin_mode TEXT DEFAULT 'ISOLATED',
                stop_loss REAL,
                take_profit REAL,
                trailing_stop_pct REAL,
                trailing_stop_activation REAL,
                break_even_activated INTEGER DEFAULT 0,
                confidence_score REAL,
                market_regime TEXT,
                entry_reason TEXT,
                exit_reason TEXT,
                realized_pnl REAL DEFAULT 0.0,
                fees REAL DEFAULT 0.0,
                funding_fees REAL DEFAULT 0.0,
                is_paper INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)

            # Orders Table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                order_id TEXT PRIMARY KEY,
                binance_order_id TEXT,
                position_id TEXT,
                symbol TEXT NOT NULL,
                market_type TEXT NOT NULL,
                side TEXT NOT NULL,
                order_type TEXT NOT NULL,
                price REAL,
                quantity REAL NOT NULL,
                status TEXT NOT NULL,
                executed_qty REAL DEFAULT 0.0,
                avg_fill_price REAL DEFAULT 0.0,
                fee REAL DEFAULT 0.0,
                is_paper INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(position_id) REFERENCES positions(position_id)
            )
            """)

            # Daily P&L and Risk State Table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS daily_state (
                date TEXT PRIMARY KEY,
                realized_pnl REAL DEFAULT 0.0,
                unrealized_pnl REAL DEFAULT 0.0,
                total_fees REAL DEFAULT 0.0,
                funding_fees REAL DEFAULT 0.0,
                trade_count INTEGER DEFAULT 0,
                is_loss_locked INTEGER DEFAULT 0,
                locked_at TIMESTAMP
            )
            """)

            # Key-Value System State Table (Emergency stop, Cooldowns, System flags)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS system_state (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)
            
            conn.commit()

    # System State Management
    def set_system_state(self, key: str, value: Any):
        val_str = json.dumps(value) if not isinstance(value, str) else value
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO system_state (key, value, updated_at)
            VALUES (?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=CURRENT_TIMESTAMP
            """, (key, val_str))
            conn.commit()

    def get_system_state(self, key: str, default: Any = None) -> Any:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM system_state WHERE key = ?", (key,))
            row = cursor.fetchone()
            if not row:
                return default
            val = row["value"]
            try:
                return json.loads(val)
            except Exception:
                return val

    # Emergency Stop Flag
    def is_emergency_stop(self) -> bool:
        return bool(self.get_system_state("emergency_stop", False))

    def set_emergency_stop(self, stop: bool):
        self.set_system_state("emergency_stop", stop)

    # Position Management
    def save_position(self, pos_data: Dict[str, Any]):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO positions (
                position_id, symbol, market_type, side, status, entry_price, exit_price,
                quantity, leverage, margin_mode, stop_loss, take_profit, trailing_stop_pct,
                trailing_stop_activation, break_even_activated, confidence_score, market_regime,
                entry_reason, exit_reason, realized_pnl, fees, funding_fees, is_paper, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(position_id) DO UPDATE SET
                status=excluded.status,
                exit_price=excluded.exit_price,
                quantity=excluded.quantity,
                stop_loss=excluded.stop_loss,
                take_profit=excluded.take_profit,
                trailing_stop_pct=excluded.trailing_stop_pct,
                trailing_stop_activation=excluded.trailing_stop_activation,
                break_even_activated=excluded.break_even_activated,
                exit_reason=excluded.exit_reason,
                realized_pnl=excluded.realized_pnl,
                fees=excluded.fees,
                funding_fees=excluded.funding_fees,
                updated_at=CURRENT_TIMESTAMP
            """, (
                pos_data["position_id"], pos_data["symbol"], pos_data["market_type"], pos_data["side"],
                pos_data.get("status", "OPEN"), pos_data["entry_price"], pos_data.get("exit_price"),
                pos_data["quantity"], pos_data.get("leverage", 1), pos_data.get("margin_mode", "ISOLATED"),
                pos_data.get("stop_loss"), pos_data.get("take_profit"), pos_data.get("trailing_stop_pct"),
                pos_data.get("trailing_stop_activation"), pos_data.get("break_even_activated", 0),
                pos_data.get("confidence_score"), pos_data.get("market_regime"),
                pos_data.get("entry_reason"), pos_data.get("exit_reason"),
                pos_data.get("realized_pnl", 0.0), pos_data.get("fees", 0.0), pos_data.get("funding_fees", 0.0),
                1 if pos_data.get("is_paper", True) else 0
            ))
            conn.commit()

    def get_open_positions(self, market_type: Optional[str] = None) -> List[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            if market_type:
                cursor.execute("SELECT * FROM positions WHERE status = 'OPEN' AND market_type = ?", (market_type,))
            else:
                cursor.execute("SELECT * FROM positions WHERE status = 'OPEN'")
            return [dict(row) for row in cursor.fetchall()]

    def get_all_positions(self) -> List[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM positions ORDER BY created_at DESC")
            return [dict(row) for row in cursor.fetchall()]

    # Daily P&L & Loss Lock
    def get_daily_state(self, date_str: str) -> Dict[str, Any]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM daily_state WHERE date = ?", (date_str,))
            row = cursor.fetchone()
            if row:
                return dict(row)
            return {
                "date": date_str, "realized_pnl": 0.0, "unrealized_pnl": 0.0,
                "total_fees": 0.0, "funding_fees": 0.0, "trade_count": 0, "is_loss_locked": 0
            }

    def update_daily_state(self, date_str: str, pnl_change: float = 0.0, fee_change: float = 0.0, funding_change: float = 0.0, trade_inc: int = 0, is_loss_locked: Optional[bool] = None):
        current = self.get_daily_state(date_str)
        new_pnl = current["realized_pnl"] + pnl_change
        new_fees = current["total_fees"] + fee_change
        new_funding = current["funding_fees"] + funding_change
        new_count = current["trade_count"] + trade_inc
        locked = current["is_loss_locked"] if is_loss_locked is None else (1 if is_loss_locked else 0)

        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO daily_state (date, realized_pnl, total_fees, funding_fees, trade_count, is_loss_locked, locked_at)
            VALUES (?, ?, ?, ?, ?, ?, CASE WHEN ? = 1 THEN CURRENT_TIMESTAMP ELSE NULL END)
            ON CONFLICT(date) DO UPDATE SET
                realized_pnl=?,
                total_fees=?,
                funding_fees=?,
                trade_count=?,
                is_loss_locked=?,
                locked_at=CASE WHEN ? = 1 AND locked_at IS NULL THEN CURRENT_TIMESTAMP ELSE locked_at END
            """, (date_str, new_pnl, new_fees, new_funding, new_count, locked, locked,
                  new_pnl, new_fees, new_funding, new_count, locked, locked))
            conn.commit()
