"""
Paper Trader Simulation Engine.
Simulates Spot and Futures order execution, leverage, isolated margin, fees, funding,
slippage, Stop Loss, Take Profit, Trailing Stop, Break-Even, and Daily Loss protection.
Uses the EXACT same signal engine and risk manager as Live mode.
"""

import logging
from typing import Dict, Any, List, Optional, Tuple
from bot.database import Database
from bot.risk_manager import RiskManager
from bot.position_manager import PositionManager
from bot.order_manager import OrderManager

class PaperTrader:
    """Paper trading engine providing full market simulation without real orders."""

    def __init__(self, config: Dict[str, Any], db: Optional[Database] = None, logger: Optional[logging.Logger] = None):
        self.config = config or {}
        self.db = db or Database(self.config.get("database", {}).get("db_path", "data/trading_bot.db"))
        self.logger = logger or logging.getLogger(__name__)

        self.initial_balance = float(self.config.get("trading", {}).get("initial_paper_balance", 10000.0))
        self.slippage_pct = float(self.config.get("risk", {}).get("slippage_percent", 0.05)) / 100.0

        self.spot_fee_rate = float(self.config.get("spot", {}).get("fee_rate", 0.001))
        self.futures_fee_rate = float(self.config.get("futures", {}).get("fee_rate", 0.0004))

        self.risk_manager = RiskManager(self.config, self.db)
        self.order_manager = OrderManager(self.db, self.logger)
        self.position_manager = PositionManager(self.db, logger=self.logger)

        # Initialize paper balance if not already saved in database
        current_bal = self.db.get_system_state("paper_balance_usdt", None)
        if current_bal is None:
            self.db.set_system_state("paper_balance_usdt", self.initial_balance)
            self.paper_balance = self.initial_balance
        else:
            self.paper_balance = float(current_bal)

    def get_equity(self, current_prices: Optional[Dict[str, float]] = None) -> float:
        """Calculates total paper account equity (cash balance + unrealized P&L)."""
        open_positions = self.db.get_open_positions()
        unrealized_pnl = 0.0

        if current_prices:
            for pos in open_positions:
                symbol = pos["symbol"]
                curr_p = current_prices.get(symbol)
                if curr_p:
                    entry_p = float(pos["entry_price"])
                    qty = float(pos["quantity"])
                    side = pos["side"]
                    if side in ["BUY", "LONG"]:
                        unrealized_pnl += (curr_p - entry_p) * qty
                    else:
                        unrealized_pnl += (entry_p - curr_p) * qty

        return max(0.0, self.paper_balance + unrealized_pnl)

    def execute_paper_order(
        self,
        symbol: str,
        market_type: str,
        side: str,
        price: float,
        quantity: float,
        leverage: int = 1,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        confidence_score: float = 0.0,
        market_regime: str = "NEUTRAL",
        entry_reason: str = ""
    ) -> Optional[Dict[str, Any]]:
        """Simulates paper order execution with slippage and fee calculation."""
        # Apply slippage
        if side in ["BUY", "LONG"]:
            fill_price = price * (1.0 + self.slippage_pct)
        else:
            fill_price = price * (1.0 - self.slippage_pct)

        fee_rate = self.spot_fee_rate if market_type == "SPOT" else self.futures_fee_rate
        entry_fee = fill_price * quantity * fee_rate

        # Check balance/margin availability
        required_margin = (fill_price * quantity) / leverage if market_type == "FUTURES" else fill_price * quantity

        if required_margin > self.paper_balance:
            self.logger.warning(f"Paper trade skipped: Insufficient paper balance (${self.paper_balance:.2f} available, ${required_margin:.2f} required)")
            return None

        # Deduct margin/cash
        self.paper_balance -= (required_margin + entry_fee)
        self.db.set_system_state("paper_balance_usdt", self.paper_balance)

        # Create Order Record
        order_rec = self.order_manager.create_order_record(
            symbol=symbol,
            market_type=market_type,
            side=side,
            order_type="MARKET",
            quantity=quantity,
            price=price,
            is_paper=True
        )

        # Reconcile Order
        self.order_manager.reconcile_fill(
            order_id=order_rec["order_id"],
            binance_res={
                "orderId": f"paper_{order_rec['order_id']}",
                "status": "FILLED",
                "executedQty": quantity,
                "cummulativeQuoteQty": fill_price * quantity,
                "price": fill_price
            },
            fee_rate=fee_rate
        )

        # Register Open Position
        pos = self.position_manager.open_position(
            symbol=symbol,
            market_type=market_type,
            side=side,
            entry_price=fill_price,
            quantity=quantity,
            leverage=leverage,
            stop_loss=stop_loss,
            take_profit=take_profit,
            confidence_score=confidence_score,
            market_regime=market_regime,
            entry_reason=entry_reason,
            fees=entry_fee,
            is_paper=True
        )

        return pos

    def update_open_positions(self, current_prices: Dict[str, float]):
        """Evaluates active paper positions against live prices for SL/TP/Trailing Stop triggers."""
        open_positions = self.db.get_open_positions()

        for pos in open_positions:
            symbol = pos["symbol"]
            current_price = current_prices.get(symbol)
            if not current_price:
                continue

            exit_check = self.position_manager.check_position_exits(pos, current_price)
            if exit_check:
                exit_reason, raw_exit_price = exit_check
                market_type = pos["market_type"]
                side = pos["side"]

                # Apply exit slippage
                if side in ["BUY", "LONG"]:
                    exit_price = raw_exit_price * (1.0 - self.slippage_pct)
                else:
                    exit_price = raw_exit_price * (1.0 + self.slippage_pct)

                fee_rate = self.spot_fee_rate if market_type == "SPOT" else self.futures_fee_rate
                exit_fee = exit_price * float(pos["quantity"]) * fee_rate

                closed_pos = self.position_manager.close_position(
                    pos=pos,
                    exit_price=exit_price,
                    exit_reason=exit_reason,
                    exit_fee=exit_fee
                )

                # Return margin and P&L to paper balance
                leverage = int(pos.get("leverage", 1))
                entry_margin = (float(pos["entry_price"]) * float(pos["quantity"])) / leverage
                net_pnl = float(closed_pos["realized_pnl"])

                self.paper_balance += (entry_margin + net_pnl)
                self.db.set_system_state("paper_balance_usdt", self.paper_balance)
                self.logger.info(f"Updated Paper Balance: ${self.paper_balance:,.2f} USDT")
