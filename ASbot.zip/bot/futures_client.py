"""
Binance Futures Client.
Handles:
- LONG / SHORT execution
- Position mode detection (One-Way vs Hedge mode)
- Isolated margin configuration
- Dynamic leverage configuration
- Symbol filter validation
- Futures balance & funding fee retrieval
"""

import math
import logging
from typing import Dict, Any, Tuple, Optional
from bot.binance_client import BinanceClientWrapper

class FuturesClient:
    """Handles Binance USDT-M Futures trading operations and margin/leverage configuration."""

    def __init__(self, wrapper: BinanceClientWrapper, config: Dict[str, Any], logger: Optional[logging.Logger] = None):
        self.wrapper = wrapper
        self.config = config or {}
        self.logger = logger or logging.getLogger(__name__)

    def detect_position_mode(self) -> Dict[str, Any]:
        """Detects whether account is in One-Way mode or Hedge mode."""
        if not self.wrapper.client:
            return {"dualSidePosition": False} # Default One-Way

        res = self.wrapper.execute_with_retry(self.wrapper.client.futures_get_position_mode)
        # dualSidePosition: true = Hedge Mode, false = One-Way Mode
        self.logger.info(f"Binance Futures Position Mode: {'Hedge Mode' if res.get('dualSidePosition') else 'One-Way Mode'}")
        return res

    def set_margin_mode_and_leverage(self, symbol: str, leverage: int, margin_type: str = "ISOLATED") -> bool:
        """Sets margin mode (ISOLATED/CROSSED) and leverage for symbol."""
        if not self.wrapper.client:
            return True

        # Change Margin Type
        try:
            self.wrapper.execute_with_retry(
                self.wrapper.client.futures_change_margin_type,
                symbol=symbol,
                marginType=margin_type.upper()
            )
            self.logger.info(f"Futures margin mode set to {margin_type} for {symbol}")
        except Exception as e:
            # Code -4046: No need to change margin type (already set)
            if "-4046" in str(e) or "No need to change margin type" in str(e):
                pass
            else:
                self.logger.warning(f"Failed to change margin type for {symbol}: {e}")

        # Change Leverage
        try:
            self.wrapper.execute_with_retry(
                self.wrapper.client.futures_change_leverage,
                symbol=symbol,
                leverage=leverage
            )
            self.logger.info(f"Futures leverage set to {leverage}x for {symbol}")
            return True
        except Exception as e:
            self.logger.error(f"Failed to set leverage for {symbol}: {e}")
            return False

    def get_symbol_filters(self, symbol: str) -> Dict[str, Any]:
        """Fetches and parses Futures exchange info filters."""
        if not self.wrapper.client:
            return {}

        info = self.wrapper.execute_with_retry(self.wrapper.client.futures_exchange_info)
        symbols_info = {s["symbol"]: s for s in info.get("symbols", [])}
        sym_info = symbols_info.get(symbol)

        if not sym_info or sym_info.get("status") != "TRADING":
            self.logger.warning(f"Symbol {symbol} is not active on Futures.")
            return {}

        filters = {}
        for f in sym_info.get("filters", []):
            f_type = f.get("filterType")
            if f_type == "LOT_SIZE":
                filters["min_qty"] = float(f.get("minQty", 0.0))
                filters["max_qty"] = float(f.get("maxQty", 0.0))
                filters["step_size"] = float(f.get("stepSize", 0.0))
            elif f_type == "PRICE_FILTER":
                filters["min_price"] = float(f.get("minPrice", 0.0))
                filters["max_price"] = float(f.get("maxPrice", 0.0))
                filters["tick_size"] = float(f.get("tickSize", 0.0))
            elif f_type in ["MIN_NOTIONAL", "NOTIONAL"]:
                filters["min_notional"] = float(f.get("notional", f.get("minNotional", 5.0)))

        return filters

    def validate_and_format_order(self, symbol: str, price: float, quantity: float) -> Tuple[bool, float, float, str]:
        """Validates price and quantity against Futures exchange filters."""
        filters = self.get_symbol_filters(symbol)
        if not filters:
            return False, 0.0, 0.0, f"Could not retrieve active Futures filters for {symbol}"

        step_size = filters.get("step_size", 0.0)
        tick_size = filters.get("tick_size", 0.0)
        min_qty = filters.get("min_qty", 0.0)
        max_qty = filters.get("max_qty", float('inf'))
        min_notional = filters.get("min_notional", 5.0)

        if step_size > 0:
            qty_precision = int(round(-math.log10(step_size)))
            formatted_qty = round(math.floor(quantity / step_size) * step_size, qty_precision)
        else:
            formatted_qty = quantity

        if tick_size > 0:
            price_precision = int(round(-math.log10(tick_size)))
            formatted_price = round(math.floor(price / tick_size) * tick_size, price_precision)
        else:
            formatted_price = price

        if formatted_qty < min_qty:
            return False, 0.0, 0.0, f"Quantity {formatted_qty} below min allowed quantity {min_qty}"

        if formatted_qty > max_qty:
            return False, 0.0, 0.0, f"Quantity {formatted_qty} exceeds max allowed quantity {max_qty}"

        notional = formatted_price * formatted_qty
        if notional < min_notional:
            return False, 0.0, 0.0, f"Order notional (${notional:.2f}) below min required (${min_notional:.2f})"

        return True, formatted_price, formatted_qty, "Valid"

    def get_account_balance(self, asset: str = "USDT") -> float:
        """Retrieves available Futures balance."""
        if not self.wrapper.client:
            return 0.0

        balances = self.wrapper.execute_with_retry(self.wrapper.client.futures_account_balance)
        for b in balances:
            if b.get("asset") == asset:
                return float(b.get("withdrawAvailable", b.get("balance", 0.0)))
        return 0.0

    def place_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
        price: Optional[float] = None,
        order_type: str = "MARKET",
        position_side: str = "BOTH"
    ) -> Dict[str, Any]:
        """Places a Futures order on Binance."""
        if not self.wrapper.client:
            raise RuntimeError("Binance client not initialized for live orders.")

        is_valid, fmt_price, fmt_qty, reason = self.validate_and_format_order(symbol, price or 1.0, quantity)
        if not is_valid:
            self.logger.error(f"Futures order validation failed: {reason}")
            raise ValueError(f"Futures order invalid: {reason}")

        params = {
            "symbol": symbol,
            "side": side.upper(),
            "type": order_type.upper(),
            "quantity": fmt_qty,
            "positionSide": position_side.upper()
        }

        if order_type.upper() == "LIMIT":
            params["price"] = str(fmt_price)
            params["timeInForce"] = "GTC"

        res = self.wrapper.execute_with_retry(self.wrapper.client.futures_create_order, **params)
        return res
