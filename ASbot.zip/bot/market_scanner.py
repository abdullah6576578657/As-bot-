"""
Market Scanner Engine.
Scans configured symbol universe across Binance Spot and Futures.
Fetches OHLCV data, calculates indicators, evaluates weighted signals,
verifies market regime and risk constraints, and opens trades autonomously.
Supports both Paper trading and Live order execution with reconciliation.
Respects Binance API rate limits and throttling.
"""

import time
import logging
from typing import Dict, Any, List, Optional, Tuple
import pandas as pd
from bot.database import Database
from bot.indicators import TechnicalIndicators
from bot.signal_engine import SignalEngine
from bot.market_regime import MarketRegimeAnalyzer
from bot.risk_manager import RiskManager
from bot.paper_trader import PaperTrader
from bot.position_manager import PositionManager
from bot.order_manager import OrderManager
from bot.spot_client import SpotClient
from bot.futures_client import FuturesClient

class MarketScanner:
    """Market scanner scanning universe and executing validated trade opportunities."""

    def __init__(
        self,
        config: Dict[str, Any],
        paper_trader: PaperTrader,
        spot_client: Optional[SpotClient] = None,
        futures_client: Optional[FuturesClient] = None,
        logger: Optional[logging.Logger] = None
    ):
        self.config = config or {}
        self.db = Database(self.config.get("database", {}).get("db_path", "data/trading_bot.db"))
        self.logger = logger or logging.getLogger(__name__)

        self.paper_trader = paper_trader
        self.spot_client = spot_client
        self.futures_client = futures_client

        self.order_manager = OrderManager(self.db, self.logger)
        self.position_manager = PositionManager(self.db, logger=self.logger)

        self.scanner_cfg = self.config.get("scanner", {})
        self.symbols = self.scanner_cfg.get("scanner_symbols", ["BTCUSDT", "ETHUSDT", "SOLUSDT"])
        self.timeframe = self.scanner_cfg.get("timeframe", "15m")

        self.signal_engine = SignalEngine(self.config)
        self.regime_analyzer = MarketRegimeAnalyzer(self.config)
        self.risk_manager = RiskManager(self.config, self.db)

        self.market_type = self.config.get("trading", {}).get("market_type", "BOTH").upper()
        self.mode = self.config.get("trading", {}).get("mode", "PAPER").upper()

    def fetch_ohlcv_data(self, symbol: str, limit: int = 100) -> Optional[pd.DataFrame]:
        """Downloads candle data for symbol safely."""
        try:
            client = None
            if self.spot_client and self.spot_client.wrapper.client:
                client = self.spot_client.wrapper.client
            elif self.futures_client and self.futures_client.wrapper.client:
                client = self.futures_client.wrapper.client

            if client:
                klines = client.get_klines(symbol=symbol, interval=self.timeframe, limit=limit)
            else:
                import requests
                url = f"https://api.binance.com/api/v3/klines?symbol={symbol}&interval={self.timeframe}&limit={limit}"
                resp = requests.get(url, timeout=5)
                if resp.status_code != 200:
                    return None
                klines = resp.json()

            if not klines or len(klines) < 30:
                return None

            df = pd.DataFrame(klines, columns=[
                "timestamp", "open", "high", "low", "close", "volume",
                "close_time", "quote_asset_volume", "number_of_trades",
                "taker_buy_base_asset_volume", "taker_buy_quote_asset_volume", "ignore"
            ])

            for col in ["open", "high", "low", "close", "volume"]:
                df[col] = df[col].astype(float)

            return df
        except Exception as e:
            self.logger.error(f"Failed to fetch OHLCV data for {symbol}: {e}")
            return None

    def get_account_equity(self) -> float:
        """Retrieves equity for paper or live mode."""
        if self.mode == "PAPER":
            return self.paper_trader.get_equity()
        elif self.mode == "LIVE":
            spot_bal = self.spot_client.get_account_balance("USDT") if self.spot_client else 0.0
            fut_bal = self.futures_client.get_account_balance("USDT") if self.futures_client else 0.0
            return max(100.0, spot_bal + fut_bal)
        return 10000.0

    def scan_cycle(self) -> Dict[str, Any]:
        """Runs a single scan cycle over configured symbols."""
        self.logger.info(f"--- Starting Scanner Cycle ({self.timeframe}) ---")

        if self.db.is_emergency_stop():
            self.logger.warning("Emergency stop is ACTIVE. Skipping scan cycle.")
            return {"status": "EMERGENCY_STOP", "trades_opened": 0}

        account_equity = self.get_account_equity()
        is_locked, daily_loss = self.risk_manager.is_daily_loss_locked(account_equity)

        if is_locked:
            self.logger.warning(f"Daily loss limit reached (${daily_loss:.2f} USDT). Skipping scan cycle.")
            return {"status": "DAILY_LOSS_LOCKED", "trades_opened": 0}

        btc_df = self.fetch_ohlcv_data("BTCUSDT", limit=100)
        regime_info = self.regime_analyzer.analyze_regime(btc_df)
        self.logger.info(f"Market Regime: {regime_info['regime']} ({regime_info['reason']})")

        current_prices: Dict[str, float] = {}
        candidate_signals = []

        for symbol in self.symbols:
            time.sleep(0.1) # Throttling to respect rate limits
            df = self.fetch_ohlcv_data(symbol, limit=100)
            if df is None:
                continue

            current_price = df["close"].iloc[-1]
            current_prices[symbol] = current_price

            df = TechnicalIndicators.calculate_all(df)
            sig_result = self.signal_engine.evaluate(df)

            if sig_result["signal"] != "NEUTRAL":
                candidate_signals.append({
                    "symbol": symbol,
                    "signal": sig_result["signal"],
                    "confidence": sig_result["confidence"],
                    "agreeing": sig_result["agreeing_indicators"],
                    "reasons": "; ".join(sig_result["reasons"]),
                    "df": df,
                    "current_price": current_price
                })

        # Update position tracking with current live prices
        if self.mode == "PAPER":
            self.paper_trader.update_open_positions(current_prices)
        elif self.mode == "LIVE":
            # Live protective exit checking
            open_positions = self.db.get_open_positions()
            for pos in open_positions:
                curr_p = current_prices.get(pos["symbol"])
                if curr_p:
                    exit_check = self.position_manager.check_position_exits(pos, curr_p)
                    if exit_check:
                        exit_reason, exit_p = exit_check
                        self._execute_live_exit(pos, exit_p, exit_reason)

        candidate_signals.sort(key=lambda x: x["confidence"], reverse=True)

        trades_opened = 0
        max_trades_per_scan = self.risk_manager.risk_cfg.get("max_trades_per_scan", 5)

        for cand in candidate_signals:
            if trades_opened >= max_trades_per_scan:
                break

            symbol = cand["symbol"]
            raw_signal = cand["signal"]
            confidence = cand["confidence"]
            df = cand["df"]
            price = cand["current_price"]
            reasons = cand["reasons"]

            open_positions = self.db.get_open_positions()
            if any(p["symbol"] == symbol for p in open_positions):
                self.logger.info(f"Skipping {symbol}: Open position already exists.")
                continue

            # Target markets to evaluate based on config (SPOT, FUTURES, or BOTH)
            target_markets = []
            if self.market_type in ["SPOT", "BOTH"]:
                if raw_signal == "BUY":
                    target_markets.append(("SPOT", "BUY"))
            if self.market_type in ["FUTURES", "BOTH"]:
                if raw_signal == "BUY":
                    target_markets.append(("FUTURES", "LONG"))
                elif raw_signal == "SELL":
                    target_markets.append(("FUTURES", "SHORT"))

            for target_market_type, side in target_markets:
                if trades_opened >= max_trades_per_scan:
                    break

                if not self.regime_analyzer.allows_trade(regime_info, target_market_type, side):
                    self.logger.info(f"Skipping {side} on {symbol}: Disallowed by Market Regime ({regime_info['regime']}).")
                    continue

                leverage = self.risk_manager.calculate_dynamic_leverage(df, regime_info) if target_market_type == "FUTURES" else 1

                stop_loss = self.risk_manager.calculate_dynamic_stop_loss(df, side, price)
                take_profit = self.risk_manager.calculate_dynamic_take_profit(price, stop_loss, side, df)

                if target_market_type == "FUTURES":
                    if not self.risk_manager.check_liquidation_risk(price, stop_loss, side, leverage):
                        self.logger.warning(f"Skipping {symbol}: Liquidation risk too high for leverage {leverage}x.")
                        continue

                quantity = self.risk_manager.calculate_position_size(
                    account_equity=account_equity,
                    entry_price=price,
                    stop_loss=stop_loss,
                    leverage=leverage
                )

                if quantity <= 0:
                    self.logger.warning(f"Skipping {symbol}: Calculated position quantity is 0.")
                    continue

                position_val = price * quantity
                cap_valid, cap_reason = self.risk_manager.validate_new_trade_capacity(target_market_type, position_val, account_equity)
                if not cap_valid:
                    self.logger.warning(f"Skipping {symbol}: {cap_reason}")
                    continue

                if self.mode == "PAPER":
                    pos = self.paper_trader.execute_paper_order(
                        symbol=symbol,
                        market_type=target_market_type,
                        side=side,
                        price=price,
                        quantity=quantity,
                        leverage=leverage,
                        stop_loss=stop_loss,
                        take_profit=take_profit,
                        confidence_score=confidence,
                        market_regime=regime_info["regime"],
                        entry_reason=reasons
                    )
                    if pos:
                        trades_opened += 1
                        break # Successfully opened position for this candidate
                elif self.mode == "LIVE":
                    if not self.config.get("trading", {}).get("live_trading_enabled", False):
                        self.logger.error("LIVE mode requested but live_trading_enabled is False in config. Safety stop.")
                        break

                    success = self._execute_live_entry(
                        symbol=symbol,
                        market_type=target_market_type,
                        side=side,
                        price=price,
                        quantity=quantity,
                        leverage=leverage,
                        stop_loss=stop_loss,
                        take_profit=take_profit,
                        confidence=confidence,
                        regime=regime_info["regime"],
                        reasons=reasons
                    )
                    if success:
                        trades_opened += 1
                        break

        return {
            "status": "COMPLETED",
            "market_regime": regime_info["regime"],
            "candidates_found": len(candidate_signals),
            "trades_opened": trades_opened
        }

    def _execute_live_entry(
        self, symbol: str, market_type: str, side: str, price: float, quantity: float,
        leverage: int, stop_loss: float, take_profit: float, confidence: float, regime: str, reasons: str
    ) -> bool:
        """Executes a real order on Binance Spot or Futures with filter checks and order tracking."""
        try:
            if market_type == "SPOT":
                if not self.spot_client:
                    return False
                order_res = self.spot_client.place_order(symbol=symbol, side="BUY", quantity=quantity)
                fee_rate = float(self.config.get("spot", {}).get("fee_rate", 0.001))
            else: # FUTURES
                if not self.futures_client:
                    return False
                margin_mode = self.config.get("futures", {}).get("margin_mode", "ISOLATED")
                self.futures_client.set_margin_mode_and_leverage(symbol, leverage, margin_mode)
                fut_side = "BUY" if side == "LONG" else "SELL"
                order_res = self.futures_client.place_order(symbol=symbol, side=fut_side, quantity=quantity)
                fee_rate = float(self.config.get("futures", {}).get("fee_rate", 0.0004))

            order_rec = self.order_manager.create_order_record(
                symbol=symbol,
                market_type=market_type,
                side=side,
                order_type="MARKET",
                quantity=quantity,
                price=price,
                is_paper=False
            )

            fill_info = self.order_manager.reconcile_fill(order_rec["order_id"], order_res, fee_rate=fee_rate)

            self.position_manager.open_position(
                symbol=symbol,
                market_type=market_type,
                side=side,
                entry_price=fill_info["avg_fill_price"] or price,
                quantity=fill_info["executed_qty"] or quantity,
                leverage=leverage,
                stop_loss=stop_loss,
                take_profit=take_profit,
                confidence_score=confidence,
                market_regime=regime,
                entry_reason=reasons,
                fees=fill_info["fee"],
                is_paper=False
            )
            return True
        except Exception as e:
            self.logger.error(f"Live entry execution failed for {symbol}: {e}")
            return False

    def _execute_live_exit(self, pos: Dict[str, Any], exit_price: float, exit_reason: str):
        """Executes a real closing order on Binance Spot or Futures."""
        symbol = pos["symbol"]
        market_type = pos["market_type"]
        side = pos["side"]
        qty = float(pos["quantity"])

        try:
            if market_type == "SPOT":
                if self.spot_client:
                    order_res = self.spot_client.place_order(symbol=symbol, side="SELL", quantity=qty)
                    fee_rate = float(self.config.get("spot", {}).get("fee_rate", 0.001))
            else: # FUTURES
                if self.futures_client:
                    fut_side = "SELL" if side == "LONG" else "BUY"
                    order_res = self.futures_client.place_order(symbol=symbol, side=fut_side, quantity=qty)
                    fee_rate = float(self.config.get("futures", {}).get("fee_rate", 0.0004))

            exit_fee = exit_price * qty * fee_rate
            self.position_manager.close_position(pos=pos, exit_price=exit_price, exit_reason=exit_reason, exit_fee=exit_fee)
        except Exception as e:
            self.logger.error(f"Live exit execution failed for {symbol}: {e}")
