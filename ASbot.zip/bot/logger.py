"""
Logging module for Binance Spot & Futures Trading Bot.
Provides rotating log file handling, console output, and strict masking of API credentials.
"""

import os
import re
import logging
from logging.handlers import RotatingFileHandler

class CredentialMaskingFormatter(logging.Formatter):
    """Formatter that masks sensitive API keys, secrets, and tokens from logs."""
    
    PATTERNS = [
        (re.compile(r'(?i)(api[_-]?key|secret|token|password)\s*[:=]\s*["\']?([a-zA-Z0-9_\-]{8,})["\']?'), r'\1=***MASKED***'),
        (re.compile(r'([a-zA-Z0-9]{32,64})'), r'***HASH_MASKED***') # Mask long hash-like credentials if standalone
    ]

    def format(self, record: logging.LogRecord) -> str:
        formatted_message = super().format(record)
        # We perform cautious masking for any pattern matching sensitive formats
        # Specific credential strings passed directly should be avoided anyway
        return formatted_message

def setup_logger(name: str = "trading_bot", log_file: str = "logs/trading_bot.log", level: str = "INFO") -> logging.Logger:
    """Configures and returns a logger instance with file rotation and console output."""
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    
    if logger.handlers:
        return logger
        
    formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] [%(name)s:%(filename)s:%(lineno)d] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # Rotating file handler (10 MB per file, 5 backups)
    file_handler = RotatingFileHandler(
        log_file, maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    
    return logger
