"""
Market Regime Analyzer.
Determines overall market regime (BULLISH, NEUTRAL, BEARISH) using benchmark assets (e.g., BTCUSDT).
Applies filtering to long/short entries based on overall market trend and volatility conditions.
"""

from typing import Dict, Any
import pandas as pd
from bot.indicators import TechnicalIndicators

class MarketRegimeAnalyzer:
    """Analyzes benchmark symbol (BTC) performance and regime."""

    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        regime_cfg = self.config.get("market_regime", {})
        self.enabled = regime_cfg.get("enabled", True)
        self.ref_symbol = regime_cfg.get("reference_symbol", "BTCUSDT")

    def analyze_regime(self, btc_df: pd.DataFrame) -> Dict[str, Any]:
        """
        Calculates regime parameters from BTC candle DataFrame.
        Returns regime string: BULLISH, NEUTRAL, or BEARISH.
        """
        if not self.enabled or btc_df is None or len(btc_df) < 50:
            return {
                "regime": "NEUTRAL",
                "trend_strength": 0.0,
                "btc_rsi": 50.0,
                "reason": "Market regime disabled or insufficient BTC data"
            }

        df = TechnicalIndicators.ema(btc_df.copy(), period=50, col_name="ema_50")
        df = TechnicalIndicators.ema(df, period=200, col_name="ema_200")
        df = TechnicalIndicators.rsi(df, period=14)
        df = TechnicalIndicators.adx(df, period=14)

        row = df.iloc[-2] if len(df) > 1 else df.iloc[-1]

        close = row["close"]
        ema_50 = row["ema_50"]
        ema_200 = row["ema_200"]
        rsi = row["rsi"]
        adx = row["adx"]

        bullish_signals = 0
        bearish_signals = 0

        # EMA structure
        if close > ema_50 and ema_50 > ema_200:
            bullish_signals += 2
        elif close < ema_50 and ema_50 < ema_200:
            bearish_signals += 2
        elif close > ema_200:
            bullish_signals += 1
        else:
            bearish_signals += 1

        # RSI filter
        if rsi > 55:
            bullish_signals += 1
        elif rsi < 45:
            bearish_signals += 1

        # ADX trend confirmation
        if adx > 25:
            if row["plus_di"] > row["minus_di"]:
                bullish_signals += 1
            else:
                bearish_signals += 1

        if bullish_signals >= 3 and bullish_signals > bearish_signals:
            regime = "BULLISH"
        elif bearish_signals >= 3 and bearish_signals > bullish_signals:
            regime = "BEARISH"
        else:
            regime = "NEUTRAL"

        return {
            "regime": regime,
            "btc_price": close,
            "btc_rsi": round(rsi, 2),
            "adx": round(adx, 2),
            "bullish_score": bullish_signals,
            "bearish_score": bearish_signals,
            "reason": f"BTC Price ${close:,.2f} | EMA50/200 structure | RSI {rsi:.1f} | ADX {adx:.1f}"
        }

    def allows_trade(self, regime_info: Dict[str, Any], market_type: str, side: str) -> bool:
        """
        Determines if a trade is permitted under current market regime.
        - Strongly Bearish market: reduce/block Spot Buy and Futures Long entries.
        - Strongly Bullish market: allows Futures Short only if signal score is very strong (checked in risk manager).
        """
        if not self.enabled:
            return True

        regime = regime_info.get("regime", "NEUTRAL")

        if regime == "BEARISH":
            if market_type == "SPOT" or side in ["BUY", "LONG"]:
                # Pause/restrict spot and long trades in bearish regime unless config bypasses
                return False

        return True
