"""
Standalone Backtesting Framework.
Performs historical OHLCV backtests without look-ahead bias or data leakage.
Reports:
- Total Return (%)
- Net P&L (USDT)
- Win Rate (%) & Profit Factor
- Sharpe Ratio & Max Drawdown (%)
- Total Trades, Largest Win / Loss
- Spot & Futures fee accounting and equity curve
"""

import math
import logging
from typing import Dict, Any, List, Optional
import pandas as pd
import numpy as np
from bot.indicators import TechnicalIndicators
from bot.signal_engine import SignalEngine
from bot.market_regime import MarketRegimeAnalyzer
from bot.risk_manager import RiskManager

class Backtester:
    """Historical strategy backtesting engine."""

    def __init__(self, config: Dict[str, Any], logger: Optional[logging.Logger] = None):
        self.config = config or {}
        self.logger = logger or logging.getLogger(__name__)

        self.initial_balance = float(self.config.get("trading", {}).get("initial_paper_balance", 10000.0))
        self.spot_fee_rate = float(self.config.get("spot", {}).get("fee_rate", 0.001))
        self.futures_fee_rate = float(self.config.get("futures", {}).get("fee_rate", 0.0004))
        self.slippage_pct = float(self.config.get("risk", {}).get("slippage_percent", 0.05)) / 100.0

        self.signal_engine = SignalEngine(self.config)
        self.regime_analyzer = MarketRegimeAnalyzer(self.config)
        self.risk_manager = RiskManager(self.config)

    def run(self, df: pd.DataFrame, symbol: str = "BTCUSDT", market_type: str = "FUTURES") -> Dict[str, Any]:
        """
        Runs backtest step-by-step over historical DataFrame.
        Guarantees no future candle leakage by passing df[:i] to indicators/signals.
        """
        if df is None or len(df) < 100:
            return {"error": "Insufficient historical data for backtesting"}

        df = df.copy()
        for col in ["open", "high", "low", "close", "volume"]:
            df[col] = df[col].astype(float)

        balance = self.initial_balance
        equity_curve = [balance]
        trades: List[Dict[str, Any]] = []
        open_position: Optional[Dict[str, Any]] = None

        # Pre-calculate full indicators up to current bar to optimize, but slice df up to i for signals
        full_df = TechnicalIndicators.calculate_all(df)

        for i in range(50, len(full_df)):
            current_bar = full_df.iloc[i]
            prev_bar = full_df.iloc[i-1]
            hist_df = full_df.iloc[:i+1] # Sliced strictly up to current bar i

            current_price = current_bar["close"]
            current_time = current_bar.get("timestamp", i)

            # 1. Manage existing open position
            if open_position:
                side = open_position["side"]
                entry_p = open_position["entry_price"]
                sl = open_position["stop_loss"]
                tp = open_position["take_profit"]
                qty = open_position["quantity"]

                exit_triggered = False
                exit_price = current_price
                exit_reason = ""

                # High/Low intra-bar check for SL/TP
                if side in ["BUY", "LONG"]:
                    if current_bar["low"] <= sl:
                        exit_triggered = True
                        exit_price = sl * (1.0 - self.slippage_pct)
                        exit_reason = "STOP_LOSS"
                    elif current_bar["high"] >= tp:
                        exit_triggered = True
                        exit_price = tp * (1.0 - self.slippage_pct)
                        exit_reason = "TAKE_PROFIT"
                elif side == "SHORT":
                    if current_bar["high"] >= sl:
                        exit_triggered = True
                        exit_price = sl * (1.0 + self.slippage_pct)
                        exit_reason = "STOP_LOSS"
                    elif current_bar["low"] <= tp:
                        exit_triggered = True
                        exit_price = tp * (1.0 + self.slippage_pct)
                        exit_reason = "TAKE_PROFIT"

                if exit_triggered:
                    fee_rate = self.futures_fee_rate if market_type == "FUTURES" else self.spot_fee_rate
                    exit_fee = exit_price * qty * fee_rate
                    
                    if side in ["BUY", "LONG"]:
                        raw_pnl = (exit_price - entry_p) * qty
                    else:
                        raw_pnl = (entry_p - exit_price) * qty

                    net_pnl = raw_pnl - open_position["entry_fee"] - exit_fee
                    balance += net_pnl

                    trades.append({
                        "entry_time": open_position["entry_time"],
                        "exit_time": current_time,
                        "side": side,
                        "entry_price": entry_p,
                        "exit_price": exit_price,
                        "quantity": qty,
                        "pnl": net_pnl,
                        "exit_reason": exit_reason
                    })
                    open_position = None

            # 2. Check for new signals if no open position
            if not open_position:
                sig_res = self.signal_engine.evaluate(hist_df)
                raw_sig = sig_res["signal"]

                if raw_sig != "NEUTRAL":
                    side = "LONG" if raw_sig == "BUY" else "SHORT"
                    if market_type == "SPOT" and side == "SHORT":
                        continue

                    regime_info = self.regime_analyzer.analyze_regime(hist_df)
                    if not self.regime_analyzer.allows_trade(regime_info, market_type, side):
                        continue

                    entry_price = current_price * (1.0 + self.slippage_pct) if side in ["BUY", "LONG"] else current_price * (1.0 - self.slippage_pct)
                    
                    sl = self.risk_manager.calculate_dynamic_stop_loss(hist_df, side, entry_price)
                    tp = self.risk_manager.calculate_dynamic_take_profit(entry_price, sl, side, hist_df)
                    leverage = self.risk_manager.calculate_dynamic_leverage(hist_df, regime_info) if market_type == "FUTURES" else 1

                    qty = self.risk_manager.calculate_position_size(
                        account_equity=balance,
                        entry_price=entry_price,
                        stop_loss=sl,
                        leverage=leverage
                    )

                    if qty > 0:
                        fee_rate = self.futures_fee_rate if market_type == "FUTURES" else self.spot_fee_rate
                        entry_fee = entry_price * qty * fee_rate

                        open_position = {
                            "entry_time": current_time,
                            "side": side,
                            "entry_price": entry_price,
                            "stop_loss": sl,
                            "take_profit": tp,
                            "quantity": qty,
                            "entry_fee": entry_fee
                        }

            equity_curve.append(balance)

        # Force close any remaining position at end of backtest
        if open_position:
            last_p = full_df.iloc[-1]["close"]
            qty = open_position["quantity"]
            side = open_position["side"]
            raw_pnl = (last_p - open_position["entry_price"]) * qty if side in ["BUY", "LONG"] else (open_position["entry_price"] - last_p) * qty
            balance += raw_pnl
            trades.append({
                "entry_time": open_position["entry_time"],
                "exit_time": full_df.iloc[-1].get("timestamp", len(full_df)),
                "side": side,
                "entry_price": open_position["entry_price"],
                "exit_price": last_p,
                "quantity": qty,
                "pnl": raw_pnl,
                "exit_reason": "END_OF_BACKTEST"
            })
            equity_curve.append(balance)

        # Calculate Statistics
        total_trades = len(trades)
        wins = [t for t in trades if t["pnl"] > 0]
        losses = [t for t in trades if t["pnl"] < 0]

        win_rate = (len(wins) / total_trades * 100.0) if total_trades > 0 else 0.0
        net_pnl = balance - self.initial_balance
        total_return_pct = (net_pnl / self.initial_balance) * 100.0

        gross_profit = sum(t["pnl"] for t in wins)
        gross_loss = abs(sum(t["pnl"] for t in losses))
        profit_factor = (gross_profit / gross_loss) if gross_loss > 0 else (gross_profit if gross_profit > 0 else 0.0)

        # Drawdown calculation
        peak = self.initial_balance
        max_drawdown = 0.0
        for eq in equity_curve:
            if eq > peak:
                peak = eq
            dd = (peak - eq) / peak * 100.0
            if dd > max_drawdown:
                max_drawdown = dd

        # Sharpe ratio calculation
        returns = pd.Series(equity_curve).pct_change().dropna()
        sharpe_ratio = (returns.mean() / returns.std() * np.sqrt(252 * 96)) if len(returns) > 1 and returns.std() > 0 else 0.0

        return {
            "symbol": symbol,
            "market_type": market_type,
            "initial_balance": self.initial_balance,
            "final_balance": round(balance, 2),
            "net_pnl": round(net_pnl, 2),
            "total_return_pct": round(total_return_pct, 2),
            "total_trades": total_trades,
            "win_rate_pct": round(win_rate, 2),
            "profit_factor": round(profit_factor, 2),
            "max_drawdown_pct": round(max_drawdown, 2),
            "sharpe_ratio": round(sharpe_ratio, 2),
            "largest_win": round(max([t["pnl"] for t in trades], default=0.0), 2),
            "largest_loss": round(min([t["pnl"] for t in trades], default=0.0), 2)
        }
