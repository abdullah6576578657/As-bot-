"""
Binance API Client Wrapper.
Handles credential loading, connection testing, exponential backoff with jitter retry,
and network failure resilience. Never prints or logs API keys/secrets.
"""

import os
import time
import random
import logging
from typing import Callable, Any, Dict, Optional
from binance.client import Client
from binance.exceptions import BinanceAPIException, BinanceRequestException

class BinanceClientWrapper:
    """Wrapper around python-binance Client with resilience & non-sensitive verification."""

    def __init__(self, config: Dict[str, Any], logger: Optional[logging.Logger] = None):
        self.config = config or {}
        self.logger = logger or logging.getLogger(__name__)

        self.api_key = os.getenv("BINANCE_API_KEY", "")
        self.api_secret = os.getenv("BINANCE_API_SECRET", "")
        self.mode = self.config.get("trading", {}).get("mode", "PAPER").upper()

        self.client: Optional[Client] = None

        if self.mode == "LIVE":
            if not self.api_key or not self.api_secret:
                raise ValueError("BINANCE_API_KEY and BINANCE_API_SECRET environment variables must be set for LIVE mode.")
            self._init_client()

    def _init_client(self):
        """Initializes Binance Client and verifies connectivity safely without leaking credentials."""
        try:
            self.client = Client(self.api_key, self.api_secret)
            # Test connectivity safely
            ping_res = self.execute_with_retry(self.client.ping)
            self.logger.info("Successfully connected and pinged Binance API.")
            
            # Verify permissions (non-sensitive check)
            account_status = self.execute_with_retry(self.client.get_account_status)
            self.logger.info(f"Binance Account Status: {account_status.get('data', 'Normal')}")
        except Exception as e:
            self.logger.error("Failed to connect to Binance API.")
            raise

    def execute_with_retry(self, func: Callable, *args, max_retries: int = 5, base_delay: float = 1.0, **kwargs) -> Any:
        """
        Executes a Binance API function with exponential backoff and randomized jitter retry.
        Catches network errors and Binance API rate limits.
        """
        for attempt in range(1, max_retries + 1):
            try:
                return func(*args, **kwargs)
            except (BinanceRequestException, requests.exceptions.RequestException, TimeoutError) as net_err:
                if attempt == max_retries:
                    self.logger.error(f"Network failure after {max_retries} attempts: {net_err}")
                    raise
                sleep_time = (base_delay * (2 ** (attempt - 1))) + random.uniform(0.1, 0.5)
                self.logger.warning(f"Network error on attempt {attempt}/{max_retries}. Retrying in {sleep_time:.2f}s...")
                time.sleep(sleep_time)
            except BinanceAPIException as api_err:
                # Code 429: Rate limit hit, 418: IP banned
                if api_err.code in [-1003, 429, 418]:
                    sleep_time = (base_delay * (2 ** attempt)) + random.uniform(1.0, 3.0)
                    self.logger.warning(f"Binance Rate Limit (code {api_err.code}). Backing off for {sleep_time:.2f}s...")
                    time.sleep(sleep_time)
                else:
                    self.logger.error(f"Binance API Exception (code {api_err.code}): {api_err.message}")
                    raise
            except Exception as e:
                self.logger.error(f"Unexpected error executing API function: {e}")
                raise
