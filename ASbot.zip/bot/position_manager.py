"""
Position Manager.
Monitors active Spot and Futures positions, manages protective exits (Stop Loss, Take Profit),
updates Trailing Stop and Break-Even protection, and processes trade closures and P&L accounting.
"""

import uuid
import logging
from typing import Dict, Any, List, Optional, Tuple
from bot.database import Database
from bot.notifier import TelegramNotifier

class PositionManager:
    """Manages active position state, trailing stop updates, break-even adjustments, and exits."""

    def __init__(self, db: Optional[Database] = None, notifier: Optional[TelegramNotifier] = None, logger: Optional[logging.Logger] = None):
        self.db = db or Database()
        self.notifier = notifier
        self.logger = logger or logging.getLogger(__name__)

    def open_position(
        self,
        symbol: str,
        market_type: str,
        side: str,
        entry_price: float,
        quantity: float,
        leverage: int = 1,
        margin_mode: str = "ISOLATED",
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        trailing_stop_pct: Optional[float] = None,
        confidence_score: float = 0.0,
        market_regime: str = "NEUTRAL",
        entry_reason: str = "",
        fees: float = 0.0,
        is_paper: bool = True
    ) -> Dict[str, Any]:
        """Creates and registers a new open position."""
        position_id = f"pos_{uuid.uuid4().hex[:12]}"
        pos_data = {
            "position_id": position_id,
            "symbol": symbol,
            "market_type": market_type.upper(),
            "side": side.upper(),
            "status": "OPEN",
            "entry_price": entry_price,
            "exit_price": None,
            "quantity": quantity,
            "leverage": leverage,
            "margin_mode": margin_mode,
            "stop_loss": stop_loss,
            "take_profit": take_profit,
            "trailing_stop_pct": trailing_stop_pct,
            "trailing_stop_activation": entry_price, # Peak price tracker for trailing stop
            "break_even_activated": 0,
            "confidence_score": confidence_score,
            "market_regime": market_regime,
            "entry_reason": entry_reason,
            "exit_reason": None,
            "realized_pnl": 0.0,
            "fees": fees,
            "funding_fees": 0.0,
            "is_paper": is_paper
        }

        self.db.save_position(pos_data)
        self.logger.info(f"Opened {market_type} position {position_id} [{side} {symbol}] at ${entry_price:.4f} (Qty: {quantity})")

        if self.notifier:
            self.notifier.notify_trade_entry(pos_data)

        return pos_data

    def check_position_exits(self, pos: Dict[str, Any], current_price: float) -> Optional[Tuple[str, float]]:
        """
        Evaluates current price against Stop-Loss, Take-Profit, Trailing Stop, and Break-Even.
        Returns (exit_reason, exit_price) if exit condition met, else None.
        """
        side = pos["side"]
        entry_price = float(pos["entry_price"])
        stop_loss = float(pos["stop_loss"]) if pos.get("stop_loss") else None
        take_profit = float(pos["take_profit"]) if pos.get("take_profit") else None
        trailing_pct = float(pos["trailing_stop_pct"]) if pos.get("trailing_stop_pct") else None
        peak_price = float(pos.get("trailing_stop_activation") or entry_price)

        if side in ["BUY", "LONG"]:
            # Update peak price for Long trailing stop
            if current_price > peak_price:
                pos["trailing_stop_activation"] = current_price
                self.db.save_position(pos)
                peak_price = current_price

            # Check Stop Loss
            if stop_loss and current_price <= stop_loss:
                return "STOP_LOSS", stop_loss

            # Check Take Profit
            if take_profit and current_price >= take_profit:
                return "TAKE_PROFIT", take_profit

            # Check Trailing Stop
            if trailing_pct and peak_price > entry_price:
                trailing_sl = peak_price * (1.0 - (trailing_pct / 100.0))
                if current_price <= trailing_sl:
                    return "TRAILING_STOP", trailing_sl

            # Break-Even trigger check (e.g. if price reaches 50% toward TP, move SL to entry + fees)
            if take_profit and not pos.get("break_even_activated"):
                tp_dist = take_profit - entry_price
                if (current_price - entry_price) >= (tp_dist * 0.5):
                    # Move stop loss to entry price + 0.1% buffer for fees
                    new_sl = entry_price * 1.001
                    pos["stop_loss"] = new_sl
                    pos["break_even_activated"] = 1
                    self.db.save_position(pos)
                    self.logger.info(f"Moved SL to Break-Even for position {pos['position_id']} ({pos['symbol']}) at ${new_sl:.4f}")

        elif side == "SHORT":
            # Update trough price for Short trailing stop
            if current_price < peak_price or peak_price == 0:
                pos["trailing_stop_activation"] = current_price
                self.db.save_position(pos)
                peak_price = current_price

            # Check Stop Loss
            if stop_loss and current_price >= stop_loss:
                return "STOP_LOSS", stop_loss

            # Check Take Profit
            if take_profit and current_price <= take_profit:
                return "TAKE_PROFIT", take_profit

            # Check Trailing Stop
            if trailing_pct and peak_price < entry_price:
                trailing_sl = peak_price * (1.0 + (trailing_pct / 100.0))
                if current_price >= trailing_sl:
                    return "TRAILING_STOP", trailing_sl

            # Break-Even trigger check
            if take_profit and not pos.get("break_even_activated"):
                tp_dist = entry_price - take_profit
                if (entry_price - current_price) >= (tp_dist * 0.5):
                    new_sl = entry_price * 0.999
                    pos["stop_loss"] = new_sl
                    pos["break_even_activated"] = 1
                    self.db.save_position(pos)
                    self.logger.info(f"Moved SL to Break-Even for SHORT position {pos['position_id']} ({pos['symbol']}) at ${new_sl:.4f}")

        return None

    def close_position(self, pos: Dict[str, Any], exit_price: float, exit_reason: str, exit_fee: float = 0.0, today_str: Optional[str] = None) -> Dict[str, Any]:
        """Closes position, calculates P&L, updates database, and updates daily P&L state."""
        side = pos["side"]
        entry_price = float(pos["entry_price"])
        qty = float(pos["quantity"])
        leverage = int(pos.get("leverage", 1))

        if side in ["BUY", "LONG"]:
            raw_pnl = (exit_price - entry_price) * qty
        else: # SHORT
            raw_pnl = (entry_price - exit_price) * qty

        total_fees = float(pos.get("fees", 0.0)) + exit_fee
        funding_fees = float(pos.get("funding_fees", 0.0))
        net_pnl = raw_pnl - total_fees - funding_fees

        pos["status"] = "CLOSED"
        pos["exit_price"] = exit_price
        pos["exit_reason"] = exit_reason
        pos["realized_pnl"] = net_pnl
        pos["fees"] = total_fees

        self.db.save_position(pos)

        # Update Daily P&L state in database
        import datetime
        date_key = today_str or datetime.datetime.utcnow().strftime("%Y-%m-%d")
        self.db.update_daily_state(
            date_str=date_key,
            pnl_change=net_pnl,
            fee_change=total_fees,
            funding_change=funding_fees,
            trade_inc=1
        )

        self.logger.info(f"Closed position {pos['position_id']} [{pos['symbol']}] | Reason: {exit_reason} | Exit: ${exit_price:.4f} | Net P&L: ${net_pnl:+.2f}")

        if self.notifier:
            self.notifier.notify_trade_exit(pos)

        return pos
