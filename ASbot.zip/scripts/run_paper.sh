#!/bin/bash
# Script to run Paper Trading
python3 main.py --mode paper
