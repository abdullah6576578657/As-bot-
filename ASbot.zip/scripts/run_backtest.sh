#!/bin/bash
# Script to run Backtesting
python3 main.py --mode backtest
