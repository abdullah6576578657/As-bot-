"""
Unit and Integration Tests for Binance Spot & Futures Automated Trading Bot.
All Binance API interactions are mocked. No real orders are placed.
"""

import os
import unittest
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch
import pandas as pd
import numpy as np

from bot.indicators import TechnicalIndicators
from bot.signal_engine import SignalEngine
from bot.market_regime import MarketRegimeAnalyzer
from bot.risk_manager import RiskManager
from bot.database import Database
from bot.paper_trader import PaperTrader
from bot.position_manager import PositionManager
from bot.spot_client import SpotClient
from bot.futures_client import FuturesClient
from bot.backtester import Backtester

class TestTradingBot(unittest.TestCase):

    def setUp(self):
        self.test_db_path = "data/test_bot.db"
        if os.path.exists(self.test_db_path):
            os.remove(self.test_db_path)
        self.db = Database(self.test_db_path)

        self.config = {
            "trading": {
                "mode": "PAPER",
                "live_trading_enabled": False,
                "market_type": "BOTH",
                "initial_paper_balance": 10000.0
            },
            "spot": {"enabled": True, "fee_rate": 0.001, "min_order_usdt": 10.0},
            "futures": {
                "enabled": True,
                "margin_mode": "ISOLATED",
                "fee_rate": 0.0004,
                "dynamic_leverage": True,
                "min_leverage": 1,
                "max_leverage": 5,
                "dynamic_stop_loss": True,
                "min_stop_loss_percent": 0.5,
                "max_stop_loss_percent": 3.0,
                "dynamic_take_profit": True,
                "minimum_risk_reward": 1.5,
                "target_risk_reward": 2.0,
                "maximum_risk_reward": 4.0,
                "liquidation_safety_margin_percent": 2.0
            },
            "risk": {
                "risk_per_trade_percent": 1.0,
                "max_daily_loss_percent": 3.0,
                "max_concurrent_spot_trades": 3,
                "max_concurrent_futures_trades": 3,
                "max_total_exposure_percent": 30.0,
                "max_trades_per_scan": 5,
                "slippage_percent": 0.05
            },
            "signals": {
                "confidence_threshold": 70.0,
                "minimum_indicator_agreement": 6
            },
            "database": {"db_path": self.test_db_path}
        }

        # Create a sample DataFrame of OHLCV data
        np.random.seed(42)
        n = 100
        close = 50000 + np.cumsum(np.random.randn(n) * 50)
        self.df = pd.DataFrame({
            "timestamp": range(n),
            "open": close - 10,
            "high": close + 30,
            "low": close - 30,
            "close": close,
            "volume": np.random.randint(10, 100, size=n) * 10.0
        })

    def tearDown(self):
        if os.path.exists(self.test_db_path):
            os.remove(self.test_db_path)

    def test_indicator_calculations(self):
        df_ind = TechnicalIndicators.calculate_all(self.df)
        self.assertIn("ema_9", df_ind.columns)
        self.assertIn("rsi", df_ind.columns)
        self.assertIn("macd_hist", df_ind.columns)
        self.assertIn("bb_upper", df_ind.columns)
        self.assertIn("adx", df_ind.columns)
        self.assertIn("atr", df_ind.columns)
        self.assertEqual(len(df_ind), 100)

    def test_signal_engine_scoring(self):
        df_ind = TechnicalIndicators.calculate_all(self.df)
        engine = SignalEngine(self.config)
        res = engine.evaluate(df_ind)
        self.assertIn(res["signal"], ["BUY", "SELL", "NEUTRAL"])
        self.assertGreaterEqual(res["confidence"], 0.0)
        self.assertLessEqual(res["confidence"], 100.0)

    def test_market_regime_analysis(self):
        analyzer = MarketRegimeAnalyzer(self.config)
        res = analyzer.analyze_regime(self.df)
        self.assertIn(res["regime"], ["BULLISH", "NEUTRAL", "BEARISH"])

    def test_position_sizing_and_leverage(self):
        risk_mgr = RiskManager(self.config, self.db)
        df_ind = TechnicalIndicators.calculate_all(self.df)
        regime_info = {"regime": "NEUTRAL"}

        leverage = risk_mgr.calculate_dynamic_leverage(df_ind, regime_info)
        self.assertGreaterEqual(leverage, 1)
        self.assertLessEqual(leverage, 5)

        sl = risk_mgr.calculate_dynamic_stop_loss(df_ind, "LONG", 50000.0)
        self.assertLess(sl, 50000.0)

        qty = risk_mgr.calculate_position_size(10000.0, 50000.0, sl, leverage)
        self.assertGreater(qty, 0.0)

    def test_liquidation_risk_check(self):
        risk_mgr = RiskManager(self.config, self.db)
        # Entry 50000, SL 49000 at 5x leverage -> Safe
        self.assertTrue(risk_mgr.check_liquidation_risk(50000.0, 49000.0, "LONG", 5))
        # Extremely unsafe SL at 50x leverage (hypothetical) -> False
        self.assertFalse(risk_mgr.check_liquidation_risk(50000.0, 30000.0, "LONG", 50))

    def test_daily_loss_lock(self):
        risk_mgr = RiskManager(self.config, self.db)
        today_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        # Simulate $400 loss on $10,000 equity (4% > 3% max daily loss)
        self.db.update_daily_state(today_str, pnl_change=-400.0)
        is_locked, loss = risk_mgr.is_daily_loss_locked(10000.0)
        self.assertTrue(is_locked)

    def test_paper_trader_execution(self):
        paper = PaperTrader(self.config, self.db)
        pos = paper.execute_paper_order(
            symbol="BTCUSDT",
            market_type="FUTURES",
            side="LONG",
            price=50000.0,
            quantity=0.1,
            leverage=3,
            stop_loss=49000.0,
            take_profit=52000.0
        )
        self.assertIsNotNone(pos)
        self.assertEqual(pos["symbol"], "BTCUSDT")

        open_positions = self.db.get_open_positions()
        self.assertEqual(len(open_positions), 1)

        # Update price to trigger Take Profit
        paper.update_open_positions({"BTCUSDT": 52500.0})
        open_positions_after = self.db.get_open_positions()
        self.assertEqual(len(open_positions_after), 0)

    def test_spot_and_futures_client_filters(self):
        wrapper = MagicMock()
        wrapper.execute_with_retry.side_effect = [
            {
                "status": "TRADING",
                "filters": [
                    {"filterType": "LOT_SIZE", "minQty": "0.001", "maxQty": "100.0", "stepSize": "0.001"},
                    {"filterType": "PRICE_FILTER", "minPrice": "0.01", "maxPrice": "100000.0", "tickSize": "0.01"},
                    {"filterType": "MIN_NOTIONAL", "minNotional": "10.0"}
                ]
            }
        ]
        spot = SpotClient(wrapper, self.config)
        valid, price, qty, reason = spot.validate_and_format_order("BTCUSDT", 50000.123, 0.0505)
        self.assertTrue(valid)
        self.assertEqual(price, 50000.12)
        self.assertEqual(qty, 0.05)

    def test_backtester(self):
        backtester = Backtester(self.config)
        res = backtester.run(self.df, symbol="BTCUSDT", market_type="FUTURES")
        self.assertIn("total_return_pct", res)
        self.assertIn("win_rate_pct", res)
        self.assertIn("max_drawdown_pct", res)

    def test_emergency_stop_flag(self):
        self.assertFalse(self.db.is_emergency_stop())
        self.db.set_emergency_stop(True)
        self.assertTrue(self.db.is_emergency_stop())

if __name__ == "__main__":
    unittest.main()
