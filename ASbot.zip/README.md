# Automated Binance Spot & Futures Trading Bot

A production-ready, fully automated cryptocurrency trading bot built in Python using `python-binance`. Designed for both **Binance Spot** and **Binance Futures** (USDT-M) with strict capital protection, autonomous opportunity selection, dynamic risk management, paper trading, and backtesting.

> ⚠️ **DISCLAIMER:** This trading bot NEVER guarantees profit. Quantitative trading involves significant risk of financial loss. Always thoroughly paper trade and backtest strategies before using real funds.

---

## 🛠 Features

- **Binance Security & Connectivity:** Credentials loaded strictly from environment variables. Includes non-sensitive startup API verification, exponential backoff, jitter retry, rate limit handling, and automatic reconnection.
- **Dual Market Support:** Operates seamlessly across Spot (`BUY`/`SELL`) and Futures (`LONG`/`SHORT`) markets in `PAPER`, `LIVE`, or `BACKTEST` mode.
- **Dynamic Futures Risk Management:**
  - Dynamic Leverage (1x–5x) based on ATR volatility and ADX trend strength.
  - Dynamic Stop-Loss calculated from ATR and swing High/Low structure before position sizing.
  - Dynamic Take-Profit targets based on configurable Risk:Reward ratios.
  - Futures Liquidation Risk estimation prior to order execution.
- **12 Technical Indicators & Weighted Scoring:**
  - EMA (9, 21), RSI, MACD, Bollinger Bands, Volume Analysis, Stochastic, ADX, Fibonacci Retracements, VWAP, Ichimoku Cloud, and OBV.
  - Weighted signal engine with configurable confidence threshold (e.g. 70%) and indicator majority requirements.
- **Overall Market Regime Analyzer:** Evaluates benchmark BTC trend, RSI, and ADX to classify market state (`BULLISH`, `NEUTRAL`, `BEARISH`) and filter counter-trend entries.
- **Daily Loss Limit Protection:** Tracks daily realized P&L and automatically locks trading for the remainder of the session if daily loss limit (e.g. 3%) is reached.
- **State Persistence:** SQLite database preserves active positions, order history, daily state, emergency stop flags, and paper balances across restarts.
- **Telegram Notifications:** Alerts on startup, trade entries, exits, daily loss locks, and emergency stops (without leaking credentials).

---

## 📋 Requirements & Environment

- Python **3.10+** (tested on 3.12)
- Installed dependencies listed in `requirements.txt`:
  - `python-binance`
  - `pandas`
  - `numpy`
  - `pyyaml`
  - `pytest`
  - `requests`
  - `python-dotenv`

---

## 🚀 Installation

```bash
# 1. Clone repository
git clone <repository_url>
cd <repository_directory>

# 2. Create virtual environment (optional but recommended)
python3 -m venv venv
source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt
```

---

## ⚙️ Configuration & Environment Setup

### 1. `.env` Environment Variables

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

Edit `.env` with your API credentials:

```ini
BINANCE_API_KEY=your_binance_api_key_here
BINANCE_API_SECRET=your_binance_api_secret_here

# Required for Live Trading Safety Confirmation
LIVE_TRADING_ENABLED=false

# Telegram Notifications (Optional)
TELEGRAM_BOT_TOKEN=your_telegram_bot_token_here
TELEGRAM_CHAT_ID=your_telegram_chat_id_here
```

### 2. `config.yaml` Parameters

All strategy, scanner, risk, and indicator parameters are managed in `config.yaml`:

```yaml
trading:
  mode: PAPER                    # Options: PAPER, LIVE, BACKTEST
  live_trading_enabled: false    # Safety flag: Must be true in both env & config for LIVE order execution
  market_type: BOTH              # Options: SPOT, FUTURES, BOTH
  initial_paper_balance: 10000.0

futures:
  margin_mode: ISOLATED          # ISOLATED margin mode
  dynamic_leverage: true
  min_leverage: 1
  max_leverage: 5
  dynamic_stop_loss: true
  min_stop_loss_percent: 0.5
  max_stop_loss_percent: 3.0
  dynamic_take_profit: true
  target_risk_reward: 2.0

risk:
  risk_per_trade_percent: 1.0    # Risk 1% of equity per trade
  max_daily_loss_percent: 3.0     # Lock trading if daily loss reaches 3%
  max_concurrent_spot_trades: 3
  max_concurrent_futures_trades: 3
  max_total_exposure_percent: 30.0
```

---

## 💻 Running the Bot

### 1. Paper Trading (Default Safe Mode)

Simulates live Spot and Futures execution using live market data without real money:

```bash
python3 main.py --mode paper
# OR using helper script:
./scripts/run_paper.sh
```

### 2. Run Historical Backtesting

Runs the strategy engine over historical candles and outputs win rate, profit factor, max drawdown, Sharpe ratio, and total returns:

```bash
python3 main.py --mode backtest
# OR using helper script:
./scripts/run_backtest.sh
```

### 3. Check System Status & Active Positions

Displays current equity, daily P&L, emergency stop status, and open positions:

```bash
python3 main.py --status
```

### 4. Emergency Stop

Instantly halts trading, cancels pending entries, and persists the emergency state across restarts:

```bash
python3 main.py --stop
```

### 5. Enabling Live Trading

Live trading is **disabled by default**. To activate live order execution:
1. Ensure `BINANCE_API_KEY` and `BINANCE_API_SECRET` are set in `.env`.
2. Set `LIVE_TRADING_ENABLED=true` in `.env`.
3. Set `live_trading_enabled: true` in `config.yaml`.
4. Launch with:
```bash
python3 main.py --mode live
```

---

## 🧪 Testing

Run the full automated test suite (all Binance API calls are mocked):

```bash
python3 -m pytest tests/test_bot.py
```

---

## 📂 Project Structure

```
trading_bot/
├── main.py                # Main CLI entry point & safety checks
├── config.yaml            # Strategy & risk parameters configuration
├── requirements.txt       # Python dependencies
├── .env.example           # Environment template
├── README.md              # Project documentation
├── .gitignore             # Source control exclusions
├── bot/
│   ├── binance_client.py  # Binance API connection wrapper & backoff
│   ├── spot_client.py     # Spot order execution & filter validation
│   ├── futures_client.py  # Futures margin, leverage & position modes
│   ├── market_scanner.py  # Universe scanner & autonomous execution
│   ├── market_regime.py   # BTC market regime classification
│   ├── indicators.py      # Vectorized 12 technical indicators
│   ├── signal_engine.py    # Weighted signal engine & confidence scoring
│   ├── risk_manager.py    # Risk sizing, dynamic leverage/SL/TP, daily loss
│   ├── position_manager.py# Active position exits & P&L tracking
│   ├── order_manager.py   # Order tracking & reconciliation
│   ├── paper_trader.py    # Paper trading simulation engine
│   ├── backtester.py      # Strategy backtesting engine
│   ├── database.py        # SQLite persistence layer
│   ├── notifier.py        # Telegram notification client
│   └── logger.py          # Rotating file & console logger
├── scripts/
│   ├── run_paper.sh       # Paper trading helper script
│   └── run_backtest.sh    # Backtest helper script
└── tests/
    └── test_bot.py        # Unit and integration tests
```
